/**
 * Cleans manga titles by removing redundant labels like "raw", volume numbers, bracketed tags, etc.
 * Example: "時間停止勇者 raw 第01-22巻" -> "時間停止勇者"
 */
export function cleanMangaTitle(rawTitle: string): string {
  if (!rawTitle) return "";
  let title = rawTitle;
  
  // Remove bracket tags like [raw], 【一般コミック】, [DL版], etc.
  title = title.replace(/[\[\(【]\s*(?:raw|RAW|DL版|一般コミック|コミック|雑誌|完|DL-RAW|zip|rar)\s*[\]\)】]/gi, " ");

  // Remove standalone "raw", "RAW"
  title = title.replace(/\b(?:raw|RAW|Raw)\b/gi, " ");

  // Remove volume range like 第01-22巻, 第01～22巻, 第1-15巻, 第01巻, [第01-22巻], (第01-22巻)
  title = title.replace(/[\[\(【]?\s*第?\s*\d+\s*[-~～〜–]\s*\d+\s*巻?\s*[\]\)】]?/g, " ");
  title = title.replace(/[\[\(【]?\s*第\s*\d+\s*巻\s*[\]\)】]?/g, " ");
  title = title.replace(/[\[\(【]?\s*第\s*\d+\s*話\s*[\]\)】]?/g, " ");

  // Remove vol.01-15, vol. 01-15, vol01-15, v01-v22, etc.
  title = title.replace(/[\[\(【]?\s*vol(?:ume)?\.?\s*\d*(?:\s*[-~～〜–]\s*\d+)?\s*[\]\)】]?/gi, " ");
  title = title.replace(/[\[\(【]?\s*v\d+(?:\s*[-~～〜–]\s*v?\d+)?\s*[\]\)】]?/gi, " ");

  // Remove any remaining bracketed numbers like [1-10]
  title = title.replace(/[\[\(【]\s*\d+\s*[-~～〜–]\s*\d+\s*[\]\)】]/g, " ");

  // Clean trailing/leading dashes, underscores, colons
  title = title.replace(/^[\s\-–—_:]+|[\s\-–—_:]+$/g, "");
  // Normalize whitespaces
  title = title.replace(/\s+/g, " ").trim();
  
  return title || rawTitle;
}

/**
 * Extracts volume range string from title (e.g., "第01-22巻", "第1-15巻", "第05巻", "vol.01-08")
 */
export function extractVolumeRange(rawTitle: string): string | null {
  if (!rawTitle) return null;

  // Pattern 1: 第01-22巻, 第01～22巻, 第1-15巻, [第01-22巻]
  const match1 = rawTitle.match(/[\[\(【]?\s*(第\s*\d+\s*[-~～〜–]\s*\d+\s*巻)\s*[\]\)】]?/i);
  if (match1) return match1[1].replace(/\s+/g, "");

  // Pattern 2: 第01巻, 第1巻
  const match2 = rawTitle.match(/[\[\(【]?\s*(第\s*\d+\s*巻)\s*[\]\)】]?/i);
  if (match2) return match2[1].replace(/\s+/g, "");

  // Pattern 3: 第01-22話, 第01話
  const match3 = rawTitle.match(/[\[\(【]?\s*(第\s*\d+(?:\s*[-~～〜–]\s*\d+)?\s*話)\s*[\]\)】]?/i);
  if (match3) return match3[1].replace(/\s+/g, "");

  // Pattern 4: 01-22巻, 1-15巻
  const match4 = rawTitle.match(/[\[\(【]?\s*(\d+\s*[-~～〜–]\s*\d+\s*巻)\s*[\]\)】]?/i);
  if (match4) return match4[1].replace(/\s+/g, "");

  // Pattern 5: vol.01-15, vol.01, v01-v22
  const match5 = rawTitle.match(/[\[\(【]?\s*(vol(?:ume)?\.?\s*\d+(?:\s*[-~～〜–]\s*\d+)?)\s*[\]\)】]?/i);
  if (match5) return match5[1].trim();

  const match6 = rawTitle.match(/[\[\(【]?\s*(v\d+(?:\s*[-~～〜–]\s*v?\d+)?)\s*[\]\)】]?/i);
  if (match6) return match6[1].trim();

  // Pattern 7: [01-22]
  const match7 = rawTitle.match(/[\[\(【]\s*(\d+\s*[-~～〜–]\s*\d+)\s*[\]\)】]/);
  if (match7) return `第${match7[1].replace(/\s+/g, "")}巻`;

  return null;
}

/**
 * Returns formatted local save path
 */
export function getSaveDirectoryPath(cleanTitle: string): string {
  const safeTitle = cleanTitle.replace(/[\/\\:*?"<>|]/g, "_");
  return `DL-RAW/${safeTitle}/`;
}

/**
 * Extracts numeric volume or chapter number from a filename or label for sorting.
 * e.g. "時間停止勇者 v22.rar" -> 22, "第1-3話" -> 3
 */
export function extractVolumeNumber(fileName: string, label?: string): number {
  const text = `${label ? label + ' ' : ''}${fileName || ''}`;

  // Range like 01-22 or 1-3 -> pick the upper bound for chronological sorting
  const rangeMatch = text.match(/(?:第|v|vol(?:ume)?\.?|ch(?:apter)?)?\s*(\d+)\s*[-~～〜–]\s*(\d+)/i);
  if (rangeMatch) {
    return parseFloat(rangeMatch[2]);
  }

  // Volume / chapter with prefix
  const volMatch = text.match(/(?:v|vol(?:ume)?\.?|第|ch(?:apter)?)\s*(\d+(?:\.\d+)?)/i);
  if (volMatch) {
    return parseFloat(volMatch[1]);
  }

  // Part format
  const partMatch = text.match(/Part\s*(\d+)/i);
  if (partMatch) {
    return parseFloat(partMatch[1]);
  }

  // Any number
  const numMatch = text.match(/(\d+)/);
  if (numMatch) {
    return parseFloat(numMatch[1]);
  }

  return 0;
}

/**
 * Sorts an array of download items by volume number.
 * Defaults to descending order (降順表示: latest volumes first, e.g. v22, v21, ... v01).
 */
export function sortDownloadItems<T extends { fileName: string; volumeLabel?: string }>(
  items: T[],
  order: 'asc' | 'desc' = 'desc'
): T[] {
  return [...items].sort((a, b) => {
    const numA = extractVolumeNumber(a.fileName, a.volumeLabel);
    const numB = extractVolumeNumber(b.fileName, b.volumeLabel);
    if (numA !== numB) {
      return order === 'desc' ? numB - numA : numA - numB;
    }
    return 0;
  });
}
