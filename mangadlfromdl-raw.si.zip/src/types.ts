export interface SearchResultItem {
  id: string;
  title: string;
  cleanTitle?: string;
  volumeInfo?: string;
  url: string;
  thumbnailUrl?: string;
  date?: string;
  tags?: string[];
  snippet?: string;
}

export interface DownloadItem {
  id: string;
  fileName: string;
  volumeLabel: string;
  size?: string;
  url: string;
  provider: 'Pubg File' | 'Rapidgator' | 'Mexashare' | 'Katfile' | 'Other';
  extension?: string;
}

export type DownloadStatus =
  | 'idle'
  | 'queued'
  | 'resolving'
  | 'waiting_timer'
  | 'retrying_wait'
  | 'authenticating'
  | 'downloading'
  | 'completed'
  | 'failed'
  | 'paused';

export interface DownloadTask {
  id: string;
  itemId: string;
  fileName: string;
  volumeLabel: string;
  size: string;
  sourceUrl: string;
  directUrl?: string;
  provider: string;
  extension: string;
  status: DownloadStatus;
  timerSecondsRemaining: number;
  totalTimerSeconds: number;
  progress: number; // 0 to 100
  downloadSpeed?: string;
  downloadedSize?: string;
  errorMessage?: string;
  completedAt?: string;
  retryCount?: number;
  blobUrl?: string;
  hasBlob?: boolean;
  jobId?: string;
}

export interface MangaDetail {
  title: string;
  cleanTitle: string;
  url: string;
  coverImage?: string;
  description?: string;
  categories?: string[];
  downloadGroups: {
    provider: string;
    items: DownloadItem[];
  }[];
  rawHtmlSnippet?: string;
}

export interface ScrapeLog {
  timestamp: string;
  step: number;
  level: 'info' | 'success' | 'warn' | 'error';
  message: string;
  details?: any;
}

