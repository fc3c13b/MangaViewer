import React, { useState } from 'react';
import { MangaDetail, DownloadItem } from '../types';
import { sortDownloadItems } from '../utils/titleHelper';
import {
  Download,
  Copy,
  Check,
  ExternalLink,
  ShieldAlert,
  FileArchive,
  HardDrive,
  CheckCircle2,
  Sparkles,
  Layers,
  SearchCode,
  ArrowUpDown
} from 'lucide-react';

interface DownloadListProps {
  detail: MangaDetail;
  onInspectLink: (item: DownloadItem) => void;
  isLoading: boolean;
}

export const DownloadList: React.FC<DownloadListProps> = ({ detail, onInspectLink, isLoading }) => {
  const [activeTab, setActiveTab] = useState<string>('Pubg File');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [batchCopied, setBatchCopied] = useState<boolean>(false);
  // Default to descending order (最新巻が先頭: v22, v21, ... v01)
  const [sortOrder, setSortOrder] = useState<'desc' | 'asc'>('desc');

  const availableProviders = detail.downloadGroups.map((g) => g.provider);
  const currentGroup =
    detail.downloadGroups.find((g) => g.provider === activeTab) ||
    detail.downloadGroups[0] || { provider: 'Pubg File', items: [] as DownloadItem[] };

  const allItems: DownloadItem[] = detail.downloadGroups.flatMap((g) => g.items);
  const rawDisplayedItems: DownloadItem[] = activeTab === 'ALL' ? allItems : currentGroup.items;
  const displayedItems: DownloadItem[] = sortDownloadItems<DownloadItem>(rawDisplayedItems, sortOrder);

  const handleCopySingle = (item: DownloadItem) => {
    navigator.clipboard.writeText(item.url);
    setCopiedId(item.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleBatchCopy = () => {
    const urls = displayedItems.map((item) => `${item.fileName} | ${item.size || ''}\n${item.url}`).join('\n\n');
    navigator.clipboard.writeText(urls);
    setBatchCopied(true);
    setTimeout(() => setBatchCopied(false), 2000);
  };

  const handleExportText = () => {
    const urls = displayedItems.map((item) => item.url).join('\n');
    const blob = new Blob([urls], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${detail.title.replace(/[\/\?<>\\:\*\|":]/g, '_')}_${activeTab}_links.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div id="download-list-container" className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl">
      {/* Title & Header */}
      <div className="flex flex-col md:flex-row gap-4 justify-between items-start md:items-center pb-4 mb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold uppercase bg-emerald-950 text-emerald-400 border border-emerald-800 px-2 py-0.5 rounded">
              STEP 5 完了
            </span>
            <span className="text-xs text-slate-400 font-mono">
              全 {allItems.length} 個のDLリンクを抽出完了
            </span>
          </div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <FileArchive className="w-5 h-5 text-emerald-400" />
            {detail.title}
          </h2>
          <a
            href={detail.url}
            target="_blank"
            rel="noreferrer"
            className="text-xs text-indigo-400 hover:underline flex items-center gap-1 mt-1 font-mono"
          >
            <ExternalLink className="w-3 h-3" />
            {detail.url}
          </a>
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto">
          <button
            id="btn-batch-copy-links"
            onClick={handleBatchCopy}
            className="flex-1 md:flex-initial px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg flex items-center justify-center gap-1.5 transition-colors border border-slate-700"
          >
            {batchCopied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            {batchCopied ? 'コピー完了！' : `${activeTab} リンク一括コピー`}
          </button>
          <button
            id="btn-export-txt-links"
            onClick={handleExportText}
            className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-lg flex items-center justify-center gap-1.5 transition-colors shadow-md shadow-indigo-900/30"
          >
            <Download className="w-3.5 h-3.5" />
            テキスト保存 (.txt)
          </button>
        </div>
      </div>

      {/* Provider Selector Tabs */}
      <div className="flex items-center justify-between flex-wrap gap-2 mb-4 bg-slate-950/70 p-1.5 rounded-lg border border-slate-800">
        <div className="flex items-center gap-1.5 overflow-x-auto">
          {availableProviders.map((provider) => {
            const isPubg = provider.toLowerCase().includes('pubg');
            const count = detail.downloadGroups.find((g) => g.provider === provider)?.items.length || 0;
            const isCurrent = activeTab === provider;

            return (
              <button
                key={provider}
                id={`tab-provider-${provider.replace(/\s+/g, '-').toLowerCase()}`}
                onClick={() => setActiveTab(provider)}
                className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-all flex items-center gap-2 whitespace-nowrap ${
                  isCurrent
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                }`}
              >
                <span>{provider}</span>
                {isPubg && (
                  <span className="text-[10px] bg-amber-400/20 text-amber-300 border border-amber-400/30 px-1 rounded font-bold">
                    優先ターゲット
                  </span>
                )}
                <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${isCurrent ? 'bg-indigo-800 text-white' : 'bg-slate-800 text-slate-400'}`}>
                  {count}
                </span>
              </button>
            );
          })}

          <button
            id="tab-provider-all"
            onClick={() => setActiveTab('ALL')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-all flex items-center gap-1.5 ${
              activeTab === 'ALL'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>すべて ({allItems.length})</span>
          </button>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            id="btn-sort-toggle-list"
            onClick={() => setSortOrder((prev) => (prev === 'desc' ? 'asc' : 'desc'))}
            className="px-2.5 py-1 text-xs rounded bg-slate-800 hover:bg-slate-700 text-amber-300 hover:text-amber-200 border border-slate-700 font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            title="クリックで巻数の並び順（昇順/降順）を切り替え"
          >
            <ArrowUpDown className="w-3.5 h-3.5 text-amber-400" />
            <span>{sortOrder === 'desc' ? '⬇️ 降順 (最新巻順)' : '⬆️ 昇順 (1巻順)'}</span>
          </button>

          <div className="text-xs text-slate-400 px-2 font-mono flex items-center gap-1.5">
            <HardDrive className="w-3.5 h-3.5 text-slate-500" />
            <span>表示中: {displayedItems.length} 件</span>
          </div>
        </div>
      </div>

      {/* Target Notice for Pubg File */}
      {activeTab === 'Pubg File' && (
        <div className="mb-4 p-3 bg-amber-950/30 border border-amber-700/50 rounded-lg flex items-start gap-2.5 text-xs text-amber-200">
          <ShieldAlert className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
          <div className="leading-relaxed">
            <span className="font-bold text-amber-300">ユーザー指定条件（項目６・７）:</span>
            「DL先として常にPubg Fileを選び、リスト上から順にダウンロードを行う。特殊認証や待機時間(WAIT)の調査を実施可能」
            各巻の「Pubgリンク調査」ボタンを押すと、HTTP応答・待機タイマー・Captchaの検査が実行されます。
          </div>
        </div>
      )}

      {/* Download Items Table / Cards */}
      <div className="overflow-hidden rounded-lg border border-slate-800 bg-slate-950/50">
        <div className="divide-y divide-slate-800/70">
          {displayedItems.map((item, idx) => {
            const isCopied = copiedId === item.id;
            const isRar = item.extension === 'rar';

            return (
              <div
                key={item.id || idx}
                id={`download-row-${idx + 1}`}
                className="p-3.5 hover:bg-slate-900/60 transition-colors flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
              >
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  <div className="w-7 h-7 rounded bg-slate-800 text-slate-400 font-mono text-xs flex items-center justify-center flex-shrink-0">
                    {idx + 1}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap mb-0.5">
                      <span className="text-xs font-mono font-semibold text-white truncate max-w-md">
                        {item.fileName}
                      </span>
                      <span
                        className={`text-[10px] font-mono uppercase px-1.5 py-0.2 rounded font-bold ${
                          isRar ? 'bg-amber-950/80 text-amber-400 border border-amber-800/60' : 'bg-sky-950/80 text-sky-400 border border-sky-800/60'
                        }`}
                      >
                        {item.extension || 'RAR'}
                      </span>
                      {item.provider && (
                        <span className="text-[10px] bg-slate-800 text-slate-300 px-1.5 py-0.2 rounded">
                          {item.provider}
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-3 text-[11px] text-slate-400 font-mono">
                      {item.size && (
                        <span className="text-emerald-400 font-semibold flex items-center gap-1">
                          容量: {item.size}
                        </span>
                      )}
                      <span className="text-slate-500 truncate max-w-xs">{item.url}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 w-full sm:w-auto justify-end">
                  <button
                    id={`btn-copy-${item.id}`}
                    onClick={() => handleCopySingle(item)}
                    title="URLをコピー"
                    className="p-2 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors text-xs flex items-center gap-1 border border-slate-700"
                  >
                    {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span className="hidden md:inline text-[11px]">{isCopied ? '済' : 'コピー'}</span>
                  </button>

                  <button
                    id={`btn-inspect-${item.id}`}
                    onClick={() => onInspectLink(item)}
                    title="認証・待機時間の調査とDL"
                    className="px-3 py-2 rounded bg-indigo-600/90 hover:bg-indigo-500 text-white transition-colors text-[11px] font-semibold flex items-center gap-1 shadow-sm cursor-pointer"
                  >
                    <SearchCode className="w-3.5 h-3.5" />
                    <span>調査・解析</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
