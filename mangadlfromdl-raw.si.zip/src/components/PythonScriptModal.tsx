import React, { useState, useEffect } from 'react';
import { DownloadItem } from '../types';
import { cleanMangaTitle } from '../utils/titleHelper';
import axios from 'axios';
import { X, Copy, Check, Download, Terminal, FileCode2, Play, Folder } from 'lucide-react';

interface PythonScriptModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  cleanTitle?: string;
  items: DownloadItem[];
}

export const PythonScriptModal: React.FC<PythonScriptModalProps> = ({
  isOpen,
  onClose,
  title,
  cleanTitle: propCleanTitle,
  items,
}) => {
  const displayTitle = propCleanTitle || cleanMangaTitle(title);
  const [script, setScript] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);

  useEffect(() => {
    if (isOpen) {
      fetchScript();
    }
  }, [isOpen, title, displayTitle, items]);

  const fetchScript = async () => {
    setLoading(true);
    try {
      const pubgItems = items.filter((it) => it.provider === 'Pubg File' || !it.provider);
      const res = await axios.post('/api/generate-script', {
        title,
        cleanTitle: displayTitle,
        items: pubgItems.length > 0 ? pubgItems : items,
      });
      setScript(res.data.script || '');
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(script);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([script], { type: 'text/x-python;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const safeTitle = displayTitle.replace(/[\/\?<>\\:\*\|":\s]/g, '_');
    a.download = `dl_raw_${safeTitle}.py`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fadeIn">
      <div
        id="python-script-modal"
        className="bg-slate-900 border border-slate-700 rounded-2xl max-w-3xl w-full p-6 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-emerald-950/80 border border-emerald-800 text-emerald-400">
              <FileCode2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Python 自動一括ダウンローダー (スクリプト生成)</h3>
              <p className="text-xs text-slate-400 font-mono">対象作品: {displayTitle}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Instructions */}
        <div className="py-3 px-4 bg-slate-950/80 border border-slate-800 rounded-xl my-3 text-xs text-slate-300 flex flex-col gap-1 font-mono">
          <div className="text-emerald-400 font-bold flex items-center gap-1.5">
            <Terminal className="w-3.5 h-3.5" />
            ローカルPCでの実行方法:
          </div>
          <p>1. 必要なライブラリをインストール: <code className="text-amber-300">pip install requests</code></p>
          <p>2. スクリプトを実行: <code className="text-amber-300">python dl_raw_{displayTitle.substring(0, 8)}.py</code></p>
          <p className="text-[11px] text-amber-300 flex items-center gap-1">
            <Folder className="w-3.5 h-3.5" />
            保存先: 自動的に <code>~/Downloads/DL-RAW/{displayTitle}/</code> に保存されます。
          </p>
        </div>

        {/* Code View */}
        <div className="flex-1 overflow-hidden rounded-xl border border-slate-800 bg-slate-950 relative">
          {loading ? (
            <div className="h-64 flex items-center justify-center text-slate-400 gap-2">
              <div className="w-5 h-5 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin" />
              <span>スクリプト生成中...</span>
            </div>
          ) : (
            <pre className="p-4 text-xs font-mono text-emerald-300 overflow-auto h-full max-h-[350px] leading-relaxed">
              {script}
            </pre>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between pt-4 mt-3 border-t border-slate-800">
          <span className="text-xs text-slate-400 font-mono">
            {items.length} 冊のダウンロードリンクを内蔵
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors border border-slate-700"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'コピー完了' : 'コードをコピー'}</span>
            </button>
            <button
              onClick={handleDownload}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors shadow-lg shadow-emerald-900/30"
            >
              <Download className="w-3.5 h-3.5" />
              <span>.py ファイルをダウンロード</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

