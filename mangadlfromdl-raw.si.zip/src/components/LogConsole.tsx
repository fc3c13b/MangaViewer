import React, { useState } from 'react';
import { Terminal, ChevronDown, ChevronUp, Trash2, CheckCircle2, AlertCircle } from 'lucide-react';

interface LogConsoleProps {
  logs: string[];
  onClear: () => void;
}

export const LogConsole: React.FC<LogConsoleProps> = ({ logs, onClear }) => {
  const [isExpanded, setIsExpanded] = useState<boolean>(true);

  return (
    <div id="log-console-container" className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-lg font-mono text-xs">
      <div className="flex items-center justify-between px-4 py-2.5 bg-slate-950/80 border-b border-slate-800">
        <div className="flex items-center gap-2 text-slate-300">
          <Terminal className="w-4 h-4 text-emerald-400" />
          <span className="font-semibold text-white">リアルタイム実行コンソール</span>
          <span className="text-[10px] bg-slate-800 px-2 py-0.5 rounded text-slate-400">
            {logs.length} 件のログ
          </span>
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={onClear}
            className="p-1 rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
            title="ログをクリア"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1 rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
          >
            {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {isExpanded && (
        <div className="p-3.5 max-h-48 overflow-y-auto space-y-1 bg-slate-950 text-slate-300">
          {logs.length === 0 ? (
            <div className="text-slate-600 text-center py-4">実行ログはここに表示されます</div>
          ) : (
            logs.map((log, index) => {
              const isError = log.includes('Error') || log.includes('エラー') || log.includes('Warn');
              const isSuccess = log.includes('成功') || log.includes('完了') || log.includes('発見');
              const isStep = log.includes('[Step');

              let color = 'text-slate-300';
              if (isError) color = 'text-rose-400';
              else if (isSuccess) color = 'text-emerald-300';
              else if (isStep) color = 'text-indigo-300';

              return (
                <div key={index} className={`flex items-start gap-2 text-[11px] leading-relaxed ${color}`}>
                  <span className="text-slate-600 select-none">
                    {String(index + 1).padStart(2, '0')}.
                  </span>
                  <span>{log}</span>
                </div>
              );
            })
          )}
        </div>
      )}
    </div>
  );
};
