import React from 'react';
import { SearchResultItem } from '../types';
import { cleanMangaTitle, extractVolumeRange } from '../utils/titleHelper';
import { BookOpen, Calendar, CheckCircle, ArrowRight, BookMarked } from 'lucide-react';

interface SearchResultsListProps {
  results: SearchResultItem[];
  selectedUrl: string | null;
  onSelectResult: (item: SearchResultItem) => void;
  isLoading: boolean;
  query: string;
}

export const SearchResultsList: React.FC<SearchResultsListProps> = ({
  results,
  selectedUrl,
  onSelectResult,
  isLoading,
  query,
}) => {
  return (
    <div id="search-results-container" className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-indigo-400" />
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              検索結果一覧 <span className="text-xs font-normal text-slate-400 font-mono">({results.length} 件発見)</span>
            </h2>
            <p className="text-xs text-slate-400">
              作品を選択すると、各巻のダウンロードリンクを取得し順次ダウンロード準備を行います。
            </p>
          </div>
        </div>
        <div className="text-xs text-slate-400">
          キーワード: <span className="font-semibold text-indigo-300 bg-indigo-950/60 px-2 py-0.5 rounded border border-indigo-800/50">「{query}」</span>
        </div>
      </div>

      {isLoading ? (
        <div className="py-12 text-center text-slate-400 flex flex-col items-center justify-center gap-3">
          <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
          <p className="text-sm">dl-raw.si から検索結果を取得・パース中...</p>
        </div>
      ) : results.length === 0 ? (
        <div className="py-8 text-center text-slate-500 text-sm">
          検索結果がありません。上の検索バーからキーワードを入力して検索してください。
        </div>
      ) : (
        <div className="space-y-3">
          {results.map((item, index) => {
            const isSelected = selectedUrl === item.url;
            const cleaned = item.cleanTitle || cleanMangaTitle(item.title);
            const volume = item.volumeInfo || extractVolumeRange(item.title) || extractVolumeRange(cleaned);

            return (
              <div
                key={item.id || index}
                id={`search-item-${index + 1}`}
                onClick={() => onSelectResult(item)}
                className={`group relative rounded-xl border p-4 transition-all duration-200 cursor-pointer flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between ${
                  isSelected
                    ? 'border-indigo-500 bg-indigo-950/40 ring-2 ring-indigo-500/50 shadow-md shadow-indigo-950/50'
                    : 'border-slate-800 bg-slate-950/60 hover:border-slate-700 hover:bg-slate-900/60'
                }`}
              >
                <div className="flex items-start gap-3.5 flex-1 min-w-0">
                  <div className={`flex-shrink-0 w-8 h-8 rounded-lg border flex items-center justify-center font-mono font-bold text-xs ${
                    isSelected ? 'bg-indigo-600 border-indigo-400 text-white' : 'bg-slate-800 border-slate-700 text-slate-300'
                  }`}>
                    {index + 1}
                  </div>
                  <div className="flex-1 min-w-0 space-y-1.5">
                    {/* Clean Title & Volume badge */}
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="text-sm font-bold text-white group-hover:text-indigo-300 transition-colors">
                        {cleaned}
                      </h3>
                      {volume && (
                        <span className="inline-flex items-center gap-1 text-xs font-bold text-amber-300 bg-amber-950/70 border border-amber-500/40 px-2 py-0.5 rounded-md font-mono shadow-sm">
                          <BookMarked className="w-3 h-3 text-amber-400" />
                          {volume}
                        </span>
                      )}
                    </div>

                    {/* Full original title as subtitle if different */}
                    {item.title !== cleaned && (
                      <p className="text-xs text-slate-400 line-clamp-1">
                        {item.title}
                      </p>
                    )}

                    {item.snippet && (
                      <p className="text-xs text-slate-400 line-clamp-1">{item.snippet}</p>
                    )}

                    {item.date && (
                      <div className="flex items-center gap-3 text-[11px] text-slate-500 font-mono">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {item.date}
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex-shrink-0 w-full sm:w-auto flex items-center justify-end gap-2 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-800">
                  <button
                    id={`btn-select-manga-${index + 1}`}
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectResult(item);
                    }}
                    className={`w-full sm:w-auto px-4 py-2.5 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-all shadow-sm ${
                      isSelected
                        ? 'bg-indigo-600 text-white shadow-indigo-600/30'
                        : 'bg-slate-800 hover:bg-indigo-600 text-slate-200 hover:text-white border border-slate-700'
                    }`}
                  >
                    {isSelected ? (
                      <>
                        <CheckCircle className="w-4 h-4 text-emerald-300" />
                        <span>選択中 (リンク解析済)</span>
                      </>
                    ) : (
                      <>
                        <span>この作品を選択してDL</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
