import React from 'react';
import { Search, ListFilter, MousePointerClick, Globe, Download, Zap, ShieldCheck } from 'lucide-react';

interface StepPipelineProps {
  currentStep: number;
  onStepClick: (step: number) => void;
  isLoading: boolean;
}

export const StepPipeline: React.FC<StepPipelineProps> = ({ currentStep, onStepClick, isLoading }) => {
  const steps = [
    { num: 1, title: '1. サイト検索', sub: 'dl-raw.si/?s=時間停止', icon: Search },
    { num: 2, title: '2. 検索結果表示', sub: '5タイトル一覧取得', icon: ListFilter },
    { num: 3, title: '3. タイトル選択', sub: '時間停止勇者 選択', icon: MousePointerClick },
    { num: 4, title: '4. 詳細記事解析', sub: '個別ページHTML解析', icon: Globe },
    { num: 5, title: '5. DLリスト抽出', sub: 'Pubg/RG 巻別一覧', icon: Download },
    { num: 6, title: '6. Pubg順次DL', sub: '上から順に自動DL', icon: Zap },
    { num: 7, title: '7. 認証&WAIT待機', sub: 'タイマー待機＆認証', icon: ShieldCheck },
  ];

  return (
    <div id="step-pipeline" className="w-full bg-slate-900/90 border border-slate-800 rounded-xl p-4 shadow-lg backdrop-blur-md">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 bg-emerald-950/80 border border-emerald-800/80 px-2.5 py-0.5 rounded-full">
            PHASE 1 & 2 完全対応パイプライン
          </span>
          <span className="text-xs text-slate-400 font-mono">全7ステップ自動検証中</span>
        </div>
        {isLoading && (
          <div className="flex items-center gap-2 text-xs text-amber-400 font-mono">
            <span className="inline-block w-2 h-2 rounded-full bg-amber-400 animate-ping" />
            パイプライン実行中...
          </div>
        )}
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-2">
        {steps.map((step) => {
          const Icon = step.icon;
          const isActive = currentStep === step.num;
          const isCompleted = currentStep > step.num;

          let cardStyle = 'border-slate-800 bg-slate-950/40 text-slate-400 hover:border-slate-700';
          let iconBg = 'bg-slate-800 text-slate-400';
          let badgeBg = 'bg-slate-800 text-slate-500';

          if (isActive) {
            cardStyle = 'border-amber-500/80 bg-amber-950/30 text-amber-200 shadow-md shadow-amber-950/50 ring-1 ring-amber-500/40';
            iconBg = 'bg-amber-500 text-slate-950';
            badgeBg = 'bg-amber-500 text-slate-950';
          } else if (isCompleted) {
            cardStyle = 'border-emerald-700/60 bg-emerald-950/20 text-emerald-300';
            iconBg = 'bg-emerald-600 text-white';
            badgeBg = 'bg-emerald-600 text-white';
          }

          return (
            <button
              key={step.num}
              id={`pipeline-step-${step.num}`}
              onClick={() => onStepClick(step.num)}
              className={`text-left p-2.5 rounded-lg border transition-all duration-200 flex flex-col justify-between min-h-[76px] ${cardStyle}`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <div className={`p-1 rounded-md ${iconBg}`}>
                  <Icon className="w-3.5 h-3.5" />
                </div>
                <span className={`text-[10px] font-mono font-bold px-1.5 py-0.2 rounded ${badgeBg}`}>
                  {isCompleted ? '✓' : `STEP ${step.num}`}
                </span>
              </div>
              <div>
                <p className="text-[11px] font-semibold leading-tight text-white mb-0.5 truncate">{step.title}</p>
                <p className="text-[10px] text-slate-400 truncate">{step.sub}</p>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
