import React, { useState, useEffect } from 'react';
import { DownloadItem } from '../types';
import { X, ShieldCheck, Timer, ExternalLink, RefreshCw, AlertTriangle, CheckCircle, Terminal } from 'lucide-react';
import axios from 'axios';

interface LinkInspectorModalProps {
  item: DownloadItem | null;
  onClose: () => void;
}

export const LinkInspectorModal: React.FC<LinkInspectorModalProps> = ({ item, onClose }) => {
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (item) {
      runInspection(item);
    }
  }, [item]);

  const runInspection = async (targetItem: DownloadItem) => {
    setLoading(true);
    setError(null);
    setData(null);

    try {
      const res = await axios.post('/api/inspect-link', {
        url: targetItem.url,
        provider: targetItem.provider,
      });
      setData(res.data);
    } catch (err: any) {
      setError(err.message || 'リンク検査中にエラーが発生しました');
    } finally {
      setLoading(false);
    }
  };

  if (!item) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fadeIn">
      <div
        id="link-inspector-modal"
        className="bg-slate-900 border border-slate-700 rounded-2xl max-w-2xl w-full p-6 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-amber-950/80 border border-amber-800 text-amber-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Pubg File 認証・待機時間 (WAIT) 調査</h3>
              <p className="text-xs text-slate-400 font-mono">PHASE 2 先行調査モジュール (項目6・7)</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto py-4 space-y-4 pr-1">
          {/* Target File Info */}
          <div className="bg-slate-950/80 p-3.5 rounded-xl border border-slate-800">
            <div className="text-xs text-slate-400 font-semibold mb-1">対象ファイル:</div>
            <div className="text-sm font-mono text-indigo-300 font-bold mb-1">{item.fileName}</div>
            <div className="flex items-center justify-between text-xs text-slate-500 font-mono">
              <span>容量: {item.size || '不明'}</span>
              <span>プロバイダ: {item.provider}</span>
            </div>
            <div className="mt-2 text-xs font-mono text-slate-400 truncate bg-slate-900 p-2 rounded border border-slate-800">
              URL: {item.url}
            </div>
          </div>

          {loading && (
            <div className="py-12 flex flex-col items-center justify-center gap-3 text-slate-400">
              <RefreshCw className="w-8 h-8 text-amber-400 animate-spin" />
              <p className="text-sm">Pubg File サーバーへ接続し、HTTPヘッダー・認証・待機タイマーを解析中...</p>
            </div>
          )}

          {error && (
            <div className="p-4 bg-rose-950/40 border border-rose-800/60 rounded-xl text-rose-300 text-xs flex items-start gap-2.5">
              <AlertTriangle className="w-5 h-5 text-rose-400 flex-shrink-0" />
              <div>
                <p className="font-bold mb-0.5">検査エラー</p>
                <p>{error}</p>
              </div>
            </div>
          )}

          {data && (
            <div className="space-y-4">
              {/* Status Grid */}
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                  <div className="text-xs text-slate-400 flex items-center gap-1.5 mb-1">
                    <Timer className="w-4 h-4 text-amber-400" />
                    待機時間 (WAIT タイマー)
                  </div>
                  <div className="text-sm font-semibold text-white">
                    {data.hasTimer ? '⚠️ カウントダウン有り (15-30秒)' : '通常または即時レスポンス'}
                  </div>
                </div>

                <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                  <div className="text-xs text-slate-400 flex items-center gap-1.5 mb-1">
                    <ShieldCheck className="w-4 h-4 text-indigo-400" />
                    特殊認証 / Captcha
                  </div>
                  <div className="text-sm font-semibold text-white">
                    {data.hasCaptcha ? '⚠️ 認証チャレンジ検出' : '✅ 通常トークン認証のみ'}
                  </div>
                </div>
              </div>

              {/* Technical Analysis Note */}
              <div className="bg-amber-950/20 border border-amber-800/50 rounded-xl p-4 text-xs text-amber-200/90 leading-relaxed space-y-2">
                <div className="font-bold text-amber-300 flex items-center gap-1.5">
                  <CheckCircle className="w-4 h-4 text-emerald-400" />
                  Pubg File 自動ダウンロードのための調査結果 (Phase 2実装指針)
                </div>
                <p>
                  1. <strong>リダイレクト構造</strong>: dl-raw.si のリンクから Pubg File (pubgfile.com) に遷移後、ワンタイムダウンロードセッションIDが生成されます。
                </p>
                <p>
                  2. <strong>待機時間 (WAIT)</strong>: 無料ダウンロードユーザーの場合、通常 <strong>15秒〜30秒のカウントダウンタイマー</strong> がJavaScriptによって動作し、ゼロになるとPOSTリクエストで最終的な直リンク (Direct Download URL) が発行されます。
                </p>
                <p>
                  3. <strong>自動化戦略</strong>: 次フェーズ(Phase 2)では、ヘッドレスブラウザ (Playwright/Puppeteer) またはCookie/セッショントークン保持＋タイマー待機HTTPリクエストによって自動ダウンロード完了まで処理できます。
                </p>
              </div>

              {/* Logs */}
              {data.logs && data.logs.length > 0 && (
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 font-mono text-[11px] text-slate-300">
                  <div className="flex items-center gap-1.5 text-xs text-slate-400 mb-2 border-b border-slate-800 pb-1">
                    <Terminal className="w-3.5 h-3.5" />
                    実行ログ
                  </div>
                  <div className="space-y-1">
                    {data.logs.map((log: string, idx: number) => (
                      <div key={idx} className="text-slate-400">
                        {log}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between pt-4 border-t border-slate-800 gap-3">
          <button
            onClick={() => runInspection(item)}
            disabled={loading}
            className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            再検査
          </button>
          <div className="flex items-center gap-2">
            <a
              href={item.url}
              target="_blank"
              rel="noreferrer"
              className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-md shadow-indigo-900/30"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              ブラウザでリンクを開く
            </a>
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
            >
              閉じる
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
