import React, { useState, useEffect, useRef } from 'react';
import { DownloadItem, DownloadTask, DownloadStatus } from '../types';
import { cleanMangaTitle, getSaveDirectoryPath, sortDownloadItems } from '../utils/titleHelper';
import axios from 'axios';
import {
  Play,
  Pause,
  RotateCcw,
  Download,
  ShieldCheck,
  Timer,
  CheckCircle2,
  AlertCircle,
  Clock,
  Sparkles,
  Zap,
  FolderDown,
  Terminal,
  FileCode2,
  HardDrive,
  Folder,
  CheckSquare,
  Square,
  PackageCheck,
  Layers,
  ExternalLink,
  ArrowUpDown
} from 'lucide-react';

// In-memory Blob and URL cache to guarantee instant user saves without re-fetching from ephemeral server
const memoryBlobStore = new Map<string, Blob>();
const memoryObjectUrlStore = new Map<string, string>();

const normalizeCacheKey = (s: string) =>
  (s || "")
    .toLowerCase()
    .replace(/\.rar$/i, "")
    .replace(/[\s_\-–—]+/g, "")
    .replace(/[\/\\?%*:|"<>]/g, "");

const storeBlobInCache = (taskId: string, fileName: string, blob: Blob) => {
  if (!blob || blob.size === 0) return;
  memoryBlobStore.set(taskId, blob);
  if (fileName) {
    memoryBlobStore.set(fileName, blob);
    memoryBlobStore.set(normalizeCacheKey(fileName), blob);
  }
  try {
    const url = URL.createObjectURL(blob);
    memoryObjectUrlStore.set(taskId, url);
    if (fileName) {
      memoryObjectUrlStore.set(fileName, url);
      memoryObjectUrlStore.set(normalizeCacheKey(fileName), url);
    }
  } catch {}
};

const getBlobFromCache = (taskId: string, fileName: string): { blob: Blob | null; url?: string } => {
  const norm = normalizeCacheKey(fileName);
  const blob =
    memoryBlobStore.get(taskId) ||
    (fileName ? memoryBlobStore.get(fileName) : null) ||
    (norm ? memoryBlobStore.get(norm) : null) ||
    null;

  const url =
    memoryObjectUrlStore.get(taskId) ||
    (fileName ? memoryObjectUrlStore.get(fileName) : undefined) ||
    (norm ? memoryObjectUrlStore.get(norm) : undefined);

  return { blob, url };
};

interface PubgQueueDownloaderProps {
  items: DownloadItem[];
  mangaTitle: string;
  cleanTitle?: string;
  onOpenScriptModal: () => void;
  onLog: (msg: string) => void;
}

export const PubgQueueDownloader: React.FC<PubgQueueDownloaderProps> = ({
  items,
  mangaTitle,
  cleanTitle: propCleanTitle,
  onOpenScriptModal,
  onLog,
}) => {
  const displayTitle = propCleanTitle || cleanMangaTitle(mangaTitle);
  const saveDirPath = getSaveDirectoryPath(displayTitle);

  const [tasks, setTasks] = useState<DownloadTask[]>([]);
  const [selectedTaskIds, setSelectedTaskIds] = useState<Set<string>>(new Set());
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [currentIndex, setCurrentIndex] = useState<number>(-1);
  const [fastMode, setFastMode] = useState<boolean>(true); // default fast 3s for smooth UI testing
  const [concurrency, setConcurrency] = useState<number>(1); // concurrency limit: 1, 2, 3
  const [autoBrowserSave, setAutoBrowserSave] = useState<boolean>(true); // auto save enabled by default
  const [queueErrorWarning, setQueueErrorWarning] = useState<{ title: string; message: string; fileName?: string } | null>(null);
  const [showFolderModal, setShowFolderModal] = useState<boolean>(false);
  const [downloadToast, setDownloadToast] = useState<{ fileName: string; isZip?: boolean } | null>(null);

  // Auto-dismiss download toast after 7s
  useEffect(() => {
    if (downloadToast) {
      const t = setTimeout(() => setDownloadToast(null), 7000);
      return () => clearTimeout(t);
    }
  }, [downloadToast]);

  const isRunningRef = useRef(isRunning);
  isRunningRef.current = isRunning;
  const inProgressTaskIdsRef = useRef<Set<string>>(new Set());
  const tasksRef = useRef<DownloadTask[]>(tasks);
  tasksRef.current = tasks;

  // File System Access directory handle for direct PC saving
  const [dirHandle, setDirHandle] = useState<any>(null);

  // Sorting order: defaults to 'desc' (降順表示: latest volumes first, e.g. v22, v21, ... v01)
  const [sortOrder, setSortOrder] = useState<'desc' | 'asc'>('desc');

  // Initialize tasks when items change
  useEffect(() => {
    const pubgItems = items.filter((it) => it.provider === 'Pubg File' || !it.provider);
    const targetItems: DownloadItem[] = pubgItems.length > 0 ? pubgItems : items;
    // Default to descending sort (最新巻・高番号が先頭)
    const sortedItems: DownloadItem[] = sortDownloadItems<DownloadItem>(targetItems, sortOrder);
    
    const initialTasks: DownloadTask[] = sortedItems.map((item, idx) => ({
      id: `task-${idx}-${item.id}`,
      itemId: item.id,
      fileName: item.fileName,
      volumeLabel: item.volumeLabel,
      size: item.size || '70 MB',
      sourceUrl: item.url,
      provider: item.provider || 'Pubg File',
      extension: item.extension || 'rar',
      status: 'idle',
      timerSecondsRemaining: 0,
      totalTimerSeconds: 0,
      progress: 0,
    }));
    setTasks(initialTasks);
    tasksRef.current = initialTasks;
    // Select all by default for convenient bulk download
    setSelectedTaskIds(new Set(initialTasks.map((t) => t.id)));
    setIsRunning(false);
    isRunningRef.current = false;
    inProgressTaskIdsRef.current.clear();
    setCurrentIndex(-1);
  }, [items, sortOrder]);

  // Toggle sort order between descending (降順: 最新巻順) and ascending (昇順: 1巻順)
  const toggleSortOrder = () => {
    const nextOrder = sortOrder === 'desc' ? 'asc' : 'desc';
    setSortOrder(nextOrder);
    setTasks((prevTasks) => {
      const sorted = sortDownloadItems(prevTasks, nextOrder);
      tasksRef.current = sorted;
      return sorted;
    });
    onLog(`↕️ 並び順を「${nextOrder === 'desc' ? '降順 (最新巻が先頭)' : '昇順 (1巻が先頭)'}」に変更しました`);
  };

  // Toggle single task selection
  const toggleSelectTask = (taskId: string) => {
    setSelectedTaskIds((prev) => {
      const next = new Set(prev);
      if (next.has(taskId)) {
        next.delete(taskId);
      } else {
        next.add(taskId);
      }
      return next;
    });
  };

  // Toggle select all
  const toggleSelectAll = () => {
    if (selectedTaskIds.size === tasks.length) {
      setSelectedTaskIds(new Set());
    } else {
      setSelectedTaskIds(new Set(tasks.map((t) => t.id)));
    }
  };

  // Pure in-memory Blob download: GUARANTEES no new tab is ever opened in Chrome / iframes
  const triggerBlobDownload = (blob: Blob, fileName: string) => {
    const blobUrl = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.style.display = 'none';
    link.href = blobUrl;
    link.download = fileName;
    link.setAttribute('download', fileName);
    // Explicitly do NOT set target="_blank"
    link.removeAttribute('target');
    document.body.appendChild(link);
    link.click();
    setTimeout(() => {
      try {
        document.body.removeChild(link);
        URL.revokeObjectURL(blobUrl);
      } catch {}
    }, 30000);
  };

  // Select PC directory via File System Access API (with rich in-app modal if in iframe)
  const handleChooseFolder = async () => {
    // Check if running inside iframe (Chrome/Edge blocks showDirectoryPicker in iframes)
    const isIframe = typeof window !== 'undefined' && window.self !== window.top;
    if (isIframe) {
      setShowFolderModal(true);
      return;
    }

    if ('showDirectoryPicker' in window) {
      try {
        const handle = await (window as any).showDirectoryPicker({
          mode: 'readwrite',
        });
        // Create or get 'DL-RAW' subfolder
        const dlRawHandle = await handle.getDirectoryHandle('DL-RAW', { create: true });
        const safeTitle = displayTitle.replace(/[\/\\:*?"<>|]/g, '_');
        const mangaFolderHandle = await dlRawHandle.getDirectoryHandle(safeTitle, { create: true });
        setDirHandle(mangaFolderHandle);
        onLog(`📁 PC上の保存先フォルダを指定・作成しました: [選択フォルダ]/DL-RAW/${safeTitle}/`);
      } catch (err: any) {
        if (err.name === 'SecurityError') {
          setShowFolderModal(true);
        } else if (err.name !== 'AbortError') {
          onLog(`[Folder Error] フォルダ選択エラー: ${err.message}`);
        }
      }
    } else {
      setShowFolderModal(true);
    }
  };

  // Downloads a file from the server using 15MB HTTP Range chunks to bypass Cloud Run's 32MB response limit
  const fetchFileInSafeChunks = async (
    downloadUrl: string,
    onProgress?: (loaded: number, total: number) => void
  ): Promise<Blob> => {
    // 1. Get total file size via HEAD
    let totalSize = 0;
    try {
      const headRes = await fetch(downloadUrl, { method: 'HEAD' });
      if (headRes.ok) {
        totalSize = parseInt(headRes.headers.get('content-length') || '0', 10);
      }
    } catch {}

    const CHUNK_SIZE = 15 * 1024 * 1024; // 15 MB chunks (strictly below 32 MB Cloud Run limit)

    // Fallback for smaller files (<= 20MB) or unknown size
    if (!totalSize || totalSize <= 20 * 1024 * 1024) {
      const res = await fetch(downloadUrl);
      if (!res.ok) {
        let errText = `サーバーエラー (HTTP ${res.status})`;
        try {
          const errJson = await res.json();
          if (errJson.error) errText = errJson.error;
        } catch {}
        throw new Error(errText);
      }
      const blob = await res.blob();
      if (onProgress) onProgress(blob.size, blob.size);
      return blob;
    }

    // Multi-chunk Range downloading: overcomes Cloud Run 32MB limit completely
    const chunks: Blob[] = [];
    let downloaded = 0;

    while (downloaded < totalSize) {
      const start = downloaded;
      const end = Math.min(start + CHUNK_SIZE - 1, totalSize - 1);

      const chunkRes = await fetch(downloadUrl, {
        headers: {
          'Range': `bytes=${start}-${end}`
        }
      });

      if (!chunkRes.ok && chunkRes.status !== 206) {
        let errText = `チャンク転送エラー (HTTP ${chunkRes.status})`;
        try {
          const errJson = await chunkRes.json();
          if (errJson.error) errText = errJson.error;
        } catch {}
        throw new Error(errText);
      }

      const chunkBlob = await chunkRes.blob();
      chunks.push(chunkBlob);
      downloaded += chunkBlob.size;
      if (onProgress) onProgress(downloaded, totalSize);
    }

    return new Blob(chunks, { type: 'application/octet-stream' });
  };

  // Dedicated single file PC save handler with instant native browser download
  const [savingTaskId, setSavingTaskId] = useState<string | null>(null);
  const [isZippingAll, setIsZippingAll] = useState<boolean>(false);

  const handleSaveSingleTask = async (task: DownloadTask) => {
    setSavingTaskId(task.id);
    onLog(`💾 ${task.fileName} のPC保存処理を開始中... (別タブは開きません)`);

    try {
      const downloadUrl =
        task.directUrl ||
        `/api/download/cached-file?jobId=${task.jobId || ''}&filename=${encodeURIComponent(task.fileName)}&sourceUrl=${encodeURIComponent(task.sourceUrl)}`;

      // 1. Fetch file as Blob directly inside iframe using 15MB Range chunking (bypasses Cloud Run 32MB limit)
      let blob: Blob | null = getBlobFromCache(task.id, task.fileName).blob;
      if (!blob) {
        onLog(`⏳ [PC転送] データを分割受信中: ${task.fileName}...`);
        
        blob = await fetchFileInSafeChunks(downloadUrl, (loaded, total) => {
          const loadedMb = (loaded / 1024 / 1024).toFixed(1);
          const totalMb = (total / 1024 / 1024).toFixed(1);
          const pct = Math.round((loaded / total) * 100);
          onLog(` ⬇️ [データ受信中] ${task.fileName}: ${loadedMb} MB / ${totalMb} MB (${pct}%)`);
        });

        if (!blob || blob.size === 0) {
          throw new Error('受信データが0バイトです');
        }
        storeBlobInCache(task.id, task.fileName, blob);
      }

      const sizeMb = (blob.size / 1024 / 1024).toFixed(2);

      // 2. If user previously selected a custom PC directory via File System Access API
      if (dirHandle) {
        try {
          const fileHandle = await dirHandle.getFileHandle(task.fileName, { create: true });
          const writable = await fileHandle.createWritable();
          await writable.write(blob);
          await writable.close();
          onLog(`✅ 【PCフォルダ直接保存完了】 [選択フォルダ]/DL-RAW/${displayTitle}/${task.fileName} (${sizeMb} MB)`);
          setDownloadToast({ fileName: task.fileName });
          setQueueErrorWarning(null);
          setSavingTaskId(null);
          return;
        } catch (dirErr: any) {
          onLog(`⚠️ フォルダ書き込み制限 (${dirErr.message})。ブラウザ標準ダウンロードへ切り替えます。`);
        }
      }

      // 3. Blob-based native browser download (ABSOLUTELY NEVER opens a separate tab)
      triggerBlobDownload(blob, task.fileName);
      onLog(`🚀 【PC保存完了】「${task.fileName}」(${sizeMb} MB) をPCへ保存しました！PCの「ダウンロード」フォルダ (Ctrl + J) をご確認ください。`);
      setDownloadToast({ fileName: task.fileName });
      setQueueErrorWarning(null);
    } catch (err: any) {
      onLog(`🚨 保存エラー (${task.fileName}): ${err.message}`);
      setQueueErrorWarning({
        title: 'ダウンロード保存エラー',
        message: `${task.fileName}: ${err.message}。右側の「🔄 再取得」ボタンを押して再取得をお試しください。`,
        fileName: task.fileName,
      });
    } finally {
      setSavingTaskId(null);
    }
  };

  // Download all completed files individually
  const handleDownloadAllCompleted = () => {
    const completedTasks = tasks.filter((t) => t.status === 'completed');
    if (completedTasks.length === 0) {
      onLog('⚠️ ダウンロード完了済みのファイルがまだありません。まず「一括バッチDL開始」を実行してください。');
      return;
    }

    onLog(`💾 完了済みの ${completedTasks.length} 件をPCのダウンロードフォルダへ順次保存します... (別タブは開きません)`);
    completedTasks.forEach((task, index) => {
      setTimeout(() => {
        handleSaveSingleTask(task);
      }, index * 800);
    });
    setDownloadToast({ fileName: `${completedTasks.length} 件のファイル` });
  };

  // Download all completed files bundled into a single ZIP archive
  const handleDownloadZipAll = async () => {
    const completedTasks = tasks.filter((t) => t.status === 'completed');
    if (completedTasks.length === 0) {
      onLog('⚠️ ダウンロード完了済みのファイルがまだありません。まず「一括バッチDL開始」を実行してください。');
      return;
    }

    setIsZippingAll(true);
    const zipFileName = `${displayTitle}_全巻一括.zip`;
    onLog(`📦 【全巻一括ZIP生成開始】完了済みの ${completedTasks.length} 巻をZIPアーカイブにパッケージング中... (別タブは開きません)`);

    try {
      const jobIds = completedTasks.map((t) => t.jobId).filter(Boolean).join(',');
      const zipUrl = `/api/download/bundle-zip?jobIds=${encodeURIComponent(jobIds)}&title=${encodeURIComponent(displayTitle)}`;

      const res = await fetch(zipUrl);
      if (!res.ok) {
        let errText = `ZIP生成エラー (HTTP ${res.status})`;
        try {
          const errJson = await res.json();
          if (errJson.error) errText = errJson.error;
        } catch {}
        throw new Error(errText);
      }

      const blob = await res.blob();
      const zipMb = (blob.size / 1024 / 1024).toFixed(2);

      // Download via Blob: NEVER opens a separate tab!
      triggerBlobDownload(blob, zipFileName);
      onLog(`🚀 【全巻一括ZIP保存完了】「${zipFileName}」(${zipMb} MB) のダウンロードを開始しました！PCの「ダウンロード」フォルダ (Ctrl + J) をご確認ください。`);
      setDownloadToast({ fileName: zipFileName, isZip: true });
      setQueueErrorWarning(null);
    } catch (err: any) {
      onLog(`🚨 ZIP保存エラー: ${err.message}`);
      setQueueErrorWarning({
        title: 'ZIP一括保存エラー',
        message: `${err.message}。各巻の個別保存もお試しください。`,
      });
    } finally {
      setIsZippingAll(false);
    }
  };

  const updateTaskStateById = (taskId: string, patch: Partial<DownloadTask>) => {
    setTasks((prev) => {
      const updated = prev.map((t) => (t.id === taskId ? { ...t, ...patch } : t));
      tasksRef.current = updated;
      return updated;
    });
  };

  // Execute single download item with resilient retry and timeout protection
  const executeTask = async (targetTask: DownloadTask, workerNumber: number) => {
    const taskId = targetTask.id;
    const taskTitle = targetTask.fileName;

    onLog(`\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
    onLog(`▶️ [スレッド #${workerNumber}] 開始: ${taskTitle} (タイムアウト: ${fastMode ? '高速1分' : '標準3分'})`);

    // Step A: Pre-countdown wait (WAIT時間・タイマー待機)
    const waitSec = fastMode ? 3 : 10;
    onLog(` [スレッド #${workerNumber}] ⏳ サーバー待機カウントダウン (${waitSec}秒)...`);
    updateTaskStateById(taskId, {
      status: 'waiting_timer',
      totalTimerSeconds: waitSec,
      timerSecondsRemaining: waitSec,
      progress: 10,
    });

    for (let remaining = waitSec; remaining > 0; remaining--) {
      if (!isRunningRef.current) {
        updateTaskStateById(taskId, { status: 'paused' });
        return;
      }
      updateTaskStateById(taskId, {
        timerSecondsRemaining: remaining,
        progress: 10 + Math.round(((waitSec - remaining) / waitSec) * 20),
      });
      await new Promise((r) => setTimeout(r, 1000));
    }

    if (!isRunningRef.current) return;

    // Step B: Server-side background fetch
    updateTaskStateById(taskId, { status: 'authenticating', progress: 35, timerSecondsRemaining: 0 });
    onLog(` [スレッド #${workerNumber}] 🔑 特殊認証・セッション開設中...`);

    let jobId = '';
    try {
      const startRes = await axios.post('/api/download/server-fetch/start', {
        url: targetTask.sourceUrl,
        fileName: targetTask.fileName,
        fastMode: fastMode,
      });

      if (!startRes.data.success || !startRes.data.jobId) {
        throw new Error(startRes.data.error || 'サーバーダウンロードジョブの開始に失敗しました');
      }

      jobId = startRes.data.jobId;
      onLog(` [スレッド #${workerNumber}] 🚀 サーバー側受信開始 (Job #${jobId})`);
    } catch (startErr: any) {
      onLog(` [スレッド #${workerNumber}] ⚠️ 開始エラー (${startErr.message})。5秒後にリトライします...`);
      updateTaskStateById(taskId, {
        status: 'retrying_wait',
        totalTimerSeconds: 5,
        timerSecondsRemaining: 5,
      });

      for (let sec = 5; sec > 0; sec--) {
        if (!isRunningRef.current) return;
        updateTaskStateById(taskId, { timerSecondsRemaining: sec });
        await new Promise((r) => setTimeout(r, 1000));
      }

      if (!isRunningRef.current) return;

      try {
        const retryStartRes = await axios.post('/api/download/server-fetch/start', {
          url: targetTask.sourceUrl,
          fileName: targetTask.fileName,
          fastMode: fastMode,
        });
        jobId = retryStartRes.data.jobId;
        onLog(` [スレッド #${workerNumber}] ✅ リトライ接続成功 (Job #${jobId})`);
      } catch (retryStartErr: any) {
        onLog(` [スレッド #${workerNumber}] 🚨 リトライ接続失敗 (${retryStartErr.message})`);
        updateTaskStateById(taskId, { status: 'failed', errorMessage: retryStartErr.message });
        setQueueErrorWarning({
          title: 'ダウンロード開始エラー',
          message: `「${taskTitle}」の開始に失敗しました (${retryStartErr.message})。`,
          fileName: taskTitle,
        });
        return;
      }
    }

    if (!isRunningRef.current) return;

    // Step C: Poll Server-Side Download Progress
    updateTaskStateById(taskId, {
      status: 'downloading',
      progress: 40,
      downloadSpeed: 'サーバー受信中...',
      downloadedSize: `0 MB / ${targetTask.size}`,
    });

    let isServerDone = false;
    let cachedUrl = '';
    let pollFailCount = 0;

    while (!isServerDone) {
      if (!isRunningRef.current) {
        updateTaskStateById(taskId, { status: 'paused' });
        return;
      }

      await new Promise((r) => setTimeout(r, 1200));

      try {
        const statusRes = await axios.get(`/api/download/server-fetch/status?jobId=${jobId}`);
        const jobStatus = statusRes.data;

        if (jobStatus.status === 'failed') {
          const failReason = jobStatus.error || 'サーバー側での転送中にエラーが発生しました';
          onLog(` [スレッド #${workerNumber}] 🚨 ${failReason}`);
          updateTaskStateById(taskId, { status: 'failed', errorMessage: failReason });
          setQueueErrorWarning({
            title: '転送エラー / タイムアウト',
            message: `「${taskTitle}」: ${failReason}`,
            fileName: taskTitle,
          });
          return;
        }

        pollFailCount = 0;
        const downloadedMb = jobStatus.downloadedMb || '0.00';
        const totalMb = jobStatus.totalMb || targetTask.size;
        const percent = jobStatus.percent || 0;
        const speed = jobStatus.speedMb || '0.00';
        const elapsed = jobStatus.elapsedSeconds || 0;

        let speedLabel = `${speed} MB/s (${elapsed}s経過)`;
        if (jobStatus.isStalled) {
          speedLabel = `0 B/s (待機中: ${elapsed}s / TO上限: ${fastMode ? '60s' : '180s'})`;
        }

        updateTaskStateById(taskId, {
          progress: 40 + Math.round((percent / 100) * 55),
          downloadSpeed: speedLabel,
          downloadedSize: `${downloadedMb} MB / ${totalMb} MB (${percent}%)`,
          size: `${totalMb} MB`,
        });

        if (jobStatus.status === 'completed') {
          isServerDone = true;
          cachedUrl = `/api/download/cached-file?jobId=${jobId}&filename=${encodeURIComponent(targetTask.fileName)}&sourceUrl=${encodeURIComponent(targetTask.sourceUrl)}`;
          onLog(` [スレッド #${workerNumber}] ✅ サーバーディスクへ格納完了 (${downloadedMb} MB)`);
          break;
        }
      } catch (pollErr: any) {
        pollFailCount++;
        if (pollFailCount > 10) {
          const networkErrMsg = '状況確認通信が連続で途絶えました';
          updateTaskStateById(taskId, { status: 'failed', errorMessage: networkErrMsg });
          return;
        }
      }
    }

    if (!isRunningRef.current) return;

    // Step D: Direct PC Saving (if dirHandle) or Readying for Native Browser Download
    let savedToFolder = false;
    let actualMb = targetTask.size;

    if (dirHandle) {
      onLog(` [スレッド #${workerNumber}] 📥 PC指定フォルダへ直接書き込み中...`);
      updateTaskStateById(taskId, {
        status: 'completed',
        progress: 98,
        downloadSpeed: 'フォルダ書き込み中...',
        directUrl: cachedUrl,
        jobId: jobId,
      });

      try {
        const blob = await fetchFileInSafeChunks(cachedUrl);
        storeBlobInCache(taskId, targetTask.fileName, blob);
        const fileHandle = await dirHandle.getFileHandle(targetTask.fileName, { create: true });
        const writable = await fileHandle.createWritable();
        await writable.write(blob);
        await writable.close();
        savedToFolder = true;
        actualMb = `${(blob.size / 1024 / 1024).toFixed(2)} MB`;
        onLog(` [スレッド #${workerNumber}] 💾 【PC直接書き込み完了】 [指定フォルダ]/DL-RAW/${displayTitle}/${targetTask.fileName} (${actualMb})`);
      } catch (dirErr: any) {
        onLog(` [スレッド #${workerNumber}] ⚠️ フォルダ書き込み制限 (${dirErr.message})。ブラウザ保存ボタンから保存してください。`);
      }
    } else {
      onLog(` [スレッド #${workerNumber}] 💡 取得完了！下の「💾 今すぐPC保存」ボタンをクリックしてPCの「ダウンロード」フォルダへ保存してください。`);
    }

    // Step F: Mark Task Completed
    const cachedEntry = getBlobFromCache(taskId, targetTask.fileName);
    updateTaskStateById(taskId, {
      status: 'completed',
      progress: 100,
      jobId: jobId,
      downloadSpeed: savedToFolder ? '💾 PCフォルダ保存完了' : '✅ 取得完了 (PC保存準備OK)',
      directUrl: cachedUrl,
      blobUrl: cachedEntry.url,
      hasBlob: !!cachedEntry.blob,
      completedAt: new Date().toLocaleTimeString(),
    });
  };

  // Concurrent worker loop
  const runWorker = async (workerNumber: number) => {
    while (isRunningRef.current) {
      // Find next task that is selected, not completed, and not currently being processed
      const currentList = tasksRef.current;
      const targetTask = currentList.find(
        (t) => selectedTaskIds.has(t.id) && t.status !== 'completed' && !inProgressTaskIdsRef.current.has(t.id)
      );

      if (!targetTask) {
        // No more pending tasks for this worker
        break;
      }

      inProgressTaskIdsRef.current.add(targetTask.id);

      try {
        await executeTask(targetTask, workerNumber);
      } catch (err: any) {
        updateTaskStateById(targetTask.id, { status: 'failed', errorMessage: err.message });
      } finally {
        inProgressTaskIdsRef.current.delete(targetTask.id);
      }

      // Small cooldown between tasks
      await new Promise((r) => setTimeout(r, 600));
    }
  };

  const handleStartQueue = async () => {
    setIsRunning(true);
    isRunningRef.current = true;
    inProgressTaskIdsRef.current.clear();

    const selectedCount = selectedTaskIds.size;
    onLog(`\n🚀 [並行バッチDL開始] 対象: ${selectedCount}巻 / 並行スレッド数: ${concurrency}`);

    // Launch worker promises according to concurrency
    const workerCount = Math.min(concurrency, selectedCount);
    const workerPromises: Promise<void>[] = [];

    for (let w = 1; w <= workerCount; w++) {
      workerPromises.push(runWorker(w));
    }

    await Promise.all(workerPromises);

    if (isRunningRef.current) {
      setIsRunning(false);
      isRunningRef.current = false;
      const remainingUncompleted = tasksRef.current.filter((t) => selectedTaskIds.has(t.id) && t.status !== 'completed').length;
      if (remainingUncompleted === 0) {
        onLog('🎉 全ての選択タスクのダウンロードが完了しました！');
      }
    }
  };

  const handlePauseQueue = () => {
    setIsRunning(false);
    isRunningRef.current = false;
    inProgressTaskIdsRef.current.clear();
    onLog('⏸️ バッチダウンロードを一時停止しました。');
  };

  const handleResetQueue = () => {
    setIsRunning(false);
    isRunningRef.current = false;
    inProgressTaskIdsRef.current.clear();
    setCurrentIndex(-1);
    const resetList = tasks.map((t) => ({
      ...t,
      status: 'idle' as const,
      timerSecondsRemaining: 0,
      totalTimerSeconds: 0,
      progress: 0,
      errorMessage: undefined,
    }));
    setTasks(resetList);
    tasksRef.current = resetList;
    onLog('🔄 ダウンロードキューをリセットしました。');
  };

  const completedCount = tasks.filter((t) => t.status === 'completed').length;
  const totalProgressPercent = tasks.length > 0 ? Math.round((completedCount / tasks.length) * 100) : 0;
  const selectedCount = selectedTaskIds.size;

  return (
    <div id="pubg-queue-downloader" className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl space-y-5">
      {/* Top Banner & Title */}
      <div className="flex flex-col md:flex-row gap-4 justify-between items-start md:items-center pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1 flex-wrap">
            <span className="text-xs font-bold uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-2.5 py-0.5 rounded-full flex items-center gap-1.5">
              <Sparkles className="w-3 h-3 text-emerald-400" />
              正規化タイトル: {displayTitle}
            </span>
            <span className="text-xs text-amber-300 bg-amber-950/60 border border-amber-800/60 px-2 py-0.5 rounded font-mono flex items-center gap-1">
              <Folder className="w-3 h-3 text-amber-400" />
              {dirHandle ? `📁 [PC指定済] ${saveDirPath}` : `📁 [標準保存] ${saveDirPath}`}
            </span>
          </div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <FolderDown className="w-5 h-5 text-indigo-400" />
            {displayTitle} - 複数巻バッチ順次ダウンロード
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            1つのZIPにまとめず、選択された各巻のデータをバッチ処理で自動的に順次ダウンロード・保存します。
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 flex-wrap w-full md:w-auto">
          {/* Concurrency Selector */}
          <div className="flex items-center bg-slate-950/80 border border-slate-700/80 rounded-lg p-1 gap-1">
            <span className="text-xs text-slate-300 font-semibold px-1.5 flex items-center gap-1">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              並行DL数:
            </span>
            {[1, 2, 3].map((num) => (
              <button
                key={num}
                id={`btn-concurrency-${num}`}
                onClick={() => setConcurrency(num)}
                disabled={isRunning}
                className={`px-2.5 py-1 text-xs font-black rounded transition-all ${
                  concurrency === num
                    ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/30'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800 disabled:opacity-50'
                }`}
                title={`並行して同時に${num}本ダウンロード`}
              >
                {num}
              </button>
            ))}
          </div>

          {/* Sequential / Concurrent Batch Download Button */}
          {!isRunning ? (
            <button
              id="btn-start-pubg-queue"
              onClick={handleStartQueue}
              disabled={tasks.length === 0 || selectedCount === 0}
              className="px-5 py-2.5 bg-gradient-to-r from-amber-500 via-orange-500 to-emerald-500 hover:opacity-95 text-slate-950 font-extrabold text-xs sm:text-sm rounded-lg shadow-lg shadow-amber-500/20 flex items-center gap-2 transition-all disabled:opacity-50"
            >
              <Play className="w-4 h-4 fill-slate-950" />
              <span>一括バッチDL開始 ({selectedCount}巻 / 並行{concurrency}本)</span>
            </button>
          ) : (
            <button
              id="btn-pause-pubg-queue"
              onClick={handlePauseQueue}
              className="px-5 py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs sm:text-sm rounded-lg shadow-lg shadow-rose-900/30 flex items-center gap-2 transition-all"
            >
              <Pause className="w-4 h-4" />
              <span>一時停止</span>
            </button>
          )}

          <button
            id="btn-reset-pubg-queue"
            onClick={handleResetQueue}
            className="p-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors border border-slate-700"
            title="リセット"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          <button
            id="btn-open-python-script"
            onClick={onOpenScriptModal}
            className="px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors border border-slate-700"
          >
            <FileCode2 className="w-4 h-4 text-emerald-400" />
            <span>Pythonスクリプト</span>
          </button>
        </div>
      </div>

      {/* Prominent PC Save / Folder Assignment Banner */}
      <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-indigo-950/70 border-2 border-indigo-500/40 rounded-xl p-3.5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-md">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-500/20 text-indigo-300 rounded-lg border border-indigo-500/30">
            <Folder className="w-5 h-5 text-amber-400" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs font-bold text-white">PC保存先:</span>
              <span className="text-xs font-mono text-amber-300 font-bold bg-amber-950/80 px-2 py-0.5 rounded border border-amber-700/60">
                {dirHandle
                  ? `📁 [指定フォルダ] ${saveDirPath}`
                  : `📁 [標準ダウンロード] Windows「ダウンロード」フォルダ直下 (C:\\Users\\...\\Downloads)`}
              </span>
            </div>
            <p className="text-[11px] text-slate-300 mt-1">
              {dirHandle ? (
                <>PC上の指定フォルダ配下の <strong className="text-amber-300">DL-RAW/{displayTitle}/</strong> に直接保存されます。</>
              ) : (
                <>標準ではPCの <strong className="text-amber-300">「ダウンロード」フォルダ直下</strong> に保存されます（ブラウザで <kbd className="px-1.5 py-0.5 bg-slate-800 border border-slate-700 rounded text-amber-300 font-mono">Ctrl + J</kbd> を押すと保存先を確認できます）。<strong className="text-slate-200">DL-RAW/{displayTitle}/</strong> に自動分類したい場合は右側の「📂 フォルダ指定」をご利用ください。</>
              )}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap w-full sm:w-auto">
          <button
            id="btn-choose-pc-folder"
            onClick={handleChooseFolder}
            className="px-3.5 py-2 rounded-lg text-xs font-bold bg-amber-500 hover:bg-amber-400 text-slate-950 flex items-center gap-1.5 shadow-md shadow-amber-500/20 transition-all"
            title="PC上のフォルダを選択してDL-RAW配下に自動保存"
          >
            <Folder className="w-4 h-4 fill-slate-950" />
            <span>📂 フォルダ指定 (DL-RAW作成)</span>
          </button>

          {completedCount > 0 && (
            <div className="flex items-center gap-2 flex-wrap">
              <button
                id="btn-download-zip-all"
                onClick={handleDownloadZipAll}
                disabled={isZippingAll}
                className="px-3.5 py-2 rounded-lg text-xs font-black bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white flex items-center gap-1.5 shadow-lg shadow-indigo-600/30 transition-all cursor-pointer"
                title="完了した全巻を1つのZIPファイルにまとめてPCへ保存 (別タブは開きません)"
              >
                {isZippingAll ? (
                  <>
                    <RotateCcw className="w-4 h-4 animate-spin" />
                    <span>📦 ZIP生成中...</span>
                  </>
                ) : (
                  <>
                    <PackageCheck className="w-4 h-4" />
                    <span>📦 完了全巻を1つのZIPでPC保存 ({completedCount}巻)</span>
                  </>
                )}
              </button>

              <button
                id="btn-download-all-completed"
                onClick={handleDownloadAllCompleted}
                className="px-3 py-2 rounded-lg text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white flex items-center gap-1.5 shadow-md shadow-emerald-600/20 transition-all cursor-pointer"
                title="各巻を個別にPCへ順次保存 (別タブは開きません)"
              >
                <Download className="w-4 h-4" />
                <span>💾 各巻を個別保存</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Error Warning Alert if retry fails */}
      {queueErrorWarning && (
        <div
          id="queue-error-warning-banner"
          className="p-4 bg-amber-950/90 border-2 border-amber-500 rounded-xl text-amber-200 flex items-start justify-between gap-3 shadow-xl"
        >
          <div className="flex items-start gap-3 flex-1">
            <AlertCircle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
            <div className="flex-1 text-xs">
              <div className="font-bold text-sm text-amber-100 mb-1 flex items-center gap-2">
                <span>⚠️ 【エラーワーニング】 {queueErrorWarning.title}</span>
              </div>
              <p className="text-amber-200 leading-relaxed">{queueErrorWarning.message}</p>
              <div className="mt-3 flex items-center gap-2 flex-wrap">
                {queueErrorWarning.fileName && (
                  <button
                    onClick={async () => {
                      const target = tasks.find(
                        (t) =>
                          t.fileName === queueErrorWarning.fileName ||
                          t.fileName.includes(queueErrorWarning.fileName!) ||
                          queueErrorWarning.fileName!.includes(t.fileName)
                      );
                      if (target) {
                        setQueueErrorWarning(null);
                        await handleSaveSingleTask(target);
                      }
                    }}
                    className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg text-xs flex items-center gap-1.5 shadow-md shadow-amber-500/25 transition-all cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>🔄 自動再取得してPC保存</span>
                  </button>
                )}
                <button
                  onClick={() => setQueueErrorWarning(null)}
                  className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg text-slate-300 font-semibold"
                >
                  閉じる
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Directory & Progress Status Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3.5 bg-slate-950/70 rounded-xl border border-slate-800 text-xs">
        {/* Progress Overview & Select All */}
        <div className="flex flex-col justify-between">
          <div className="flex items-center justify-between mb-1">
            <div className="flex items-center gap-2.5">
              <button
                onClick={toggleSelectAll}
                className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold flex items-center gap-1.5"
              >
                {selectedTaskIds.size === tasks.length ? (
                  <CheckSquare className="w-4 h-4 text-indigo-400" />
                ) : (
                  <Square className="w-4 h-4 text-slate-500" />
                )}
                <span>全選択 ({selectedCount}/{tasks.length})</span>
              </button>

              <button
                id="btn-toggle-sort-pubg"
                onClick={toggleSortOrder}
                className="px-2 py-0.5 rounded bg-slate-800/90 hover:bg-slate-700 text-amber-300 hover:text-amber-200 border border-slate-700 text-[11px] font-bold flex items-center gap-1 transition-colors cursor-pointer"
                title="クリックで巻数の並び順（昇順/降順）を切り替え"
              >
                <ArrowUpDown className="w-3 h-3 text-amber-400" />
                <span>{sortOrder === 'desc' ? '⬇️ 降順 (最新巻順)' : '⬆️ 昇順 (1巻順)'}</span>
              </button>
            </div>
            <span className="font-mono text-slate-300 font-bold">
              {completedCount}/{tasks.length} 完了 ({totalProgressPercent}%)
            </span>
          </div>
          <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
            <div
              className="bg-gradient-to-r from-indigo-500 to-emerald-400 h-full transition-all duration-300"
              style={{ width: `${totalProgressPercent}%` }}
            />
          </div>
        </div>

        {/* Timer & Timeout Mode Toggle */}
        <div className="flex items-center justify-between border-t sm:border-t-0 sm:border-l border-slate-800 pt-2 sm:pt-0 sm:pl-3">
          <div>
            <div className="font-semibold text-white flex items-center gap-1">
              <Timer className="w-3.5 h-3.5 text-amber-400" />
              待機 & タイムアウト設定
            </div>
            <p className="text-[11px] text-slate-400">
              {fastMode ? '高速 (待機3s / TO: 1分)' : '標準 (待機10s / TO: 3分)'}
            </p>
          </div>
          <button
            onClick={() => setFastMode(!fastMode)}
            className={`px-2.5 py-1 rounded text-[11px] font-bold border transition-colors ${
              fastMode
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 hover:bg-amber-500/30'
                : 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40 hover:bg-indigo-500/30'
            }`}
            title="クリックで標準(3分TO) / 高速(1分TO)を切り替え"
          >
            {fastMode ? '高速モード (1分)' : '標準モード (3分)'}
          </button>
        </div>
      </div>

      {/* Task Queue List */}
      <div className="space-y-2.5 max-h-[520px] overflow-y-auto pr-1">
        {tasks.map((task, idx) => {
          const isSelected = selectedTaskIds.has(task.id);
          const isTaskActive = task.status === 'downloading' || task.status === 'authenticating' || task.status === 'waiting_timer';
          const isCompleted = task.status === 'completed';
          const isFailed = task.status === 'failed';
          const isRetrying = task.status === 'retrying_wait';
          const isWaiting = task.status === 'waiting_timer';
          const isAuth = task.status === 'authenticating';
          const isDownloading = task.status === 'downloading';

          let statusBadge = (
            <span className="text-[11px] font-mono text-slate-500 bg-slate-800/80 px-2 py-0.5 rounded">
              待機中
            </span>
          );

          if (isRetrying) {
            statusBadge = (
              <span className="text-[11px] font-mono font-bold text-amber-300 bg-amber-950 border border-amber-500 px-2.5 py-0.5 rounded flex items-center gap-1.5 animate-pulse">
                <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
                ⚠️ 5秒リトライ待機中 (残り {task.timerSecondsRemaining}s)
              </span>
            );
          } else if (isWaiting) {
            statusBadge = (
              <span className="text-[11px] font-mono font-bold text-amber-300 bg-amber-950/80 border border-amber-800 px-2 py-0.5 rounded flex items-center gap-1 animate-pulse">
                <Timer className="w-3 h-3" />
                待機中 (残り {task.timerSecondsRemaining}s)
              </span>
            );
          } else if (isAuth) {
            statusBadge = (
              <span className="text-[11px] font-mono font-bold text-indigo-300 bg-indigo-950/80 border border-indigo-800 px-2 py-0.5 rounded flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-indigo-400" />
                特殊認証中
              </span>
            );
          } else if (isDownloading) {
            statusBadge = (
              <span className="text-[11px] font-mono font-bold text-teal-300 bg-teal-950/80 border border-teal-800 px-2 py-0.5 rounded flex items-center gap-1">
                <Download className="w-3 h-3 animate-bounce" />
                DL転送中 ({task.progress}%)
              </span>
            );
          } else if (isCompleted) {
            statusBadge = (
              <span className="text-[11px] font-mono font-bold text-emerald-300 bg-emerald-950/80 border border-emerald-800 px-2 py-0.5 rounded flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                保存完了
              </span>
            );
          } else if (isFailed) {
            statusBadge = (
              <span className="text-[11px] font-mono font-bold text-rose-300 bg-rose-950/80 border border-rose-800 px-2 py-0.5 rounded flex items-center gap-1">
                <AlertCircle className="w-3 h-3 text-rose-400" />
                リトライ失敗
              </span>
            );
          }

          return (
            <div
              key={task.id}
              id={`queue-task-row-${idx + 1}`}
              className={`p-3.5 rounded-xl border transition-all duration-200 ${
                isTaskActive
                  ? 'bg-slate-900 border-amber-500/80 ring-1 ring-amber-500/40 shadow-lg'
                  : isCompleted
                  ? 'bg-slate-950/80 border-emerald-800/40'
                  : isSelected
                  ? 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                  : 'bg-slate-950/30 border-slate-900 opacity-60'
              }`}
            >
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  {/* Select Checkbox */}
                  <button
                    onClick={() => toggleSelectTask(task.id)}
                    className="p-1 text-slate-400 hover:text-indigo-400 transition-colors"
                  >
                    {isSelected ? (
                      <CheckSquare className="w-4 h-4 text-indigo-400" />
                    ) : (
                      <Square className="w-4 h-4 text-slate-600" />
                    )}
                  </button>

                  <div
                    className={`w-7 h-7 rounded font-mono text-xs font-bold flex items-center justify-center flex-shrink-0 ${
                      isCompleted
                        ? 'bg-emerald-900/60 text-emerald-300 border border-emerald-700'
                        : isTaskActive
                        ? 'bg-amber-500 text-slate-950 animate-pulse font-black'
                        : 'bg-slate-800 text-slate-400 border border-slate-700'
                    }`}
                  >
                    {idx + 1}
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap mb-0.5">
                      <span className="text-xs font-mono font-bold text-white truncate max-w-md">
                        {task.fileName}
                      </span>
                      <span className="text-[10px] font-mono uppercase bg-amber-950/80 text-amber-400 border border-amber-800/60 px-1.5 py-0.2 rounded font-bold">
                        {task.extension}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {task.volumeLabel}
                      </span>
                    </div>

                    <div className="flex items-center gap-3 text-[11px] text-slate-400 font-mono">
                      <span className="text-emerald-400 font-semibold">
                        {task.downloadedSize || `予定容量: ${task.size}`}
                      </span>
                      {task.downloadSpeed && (
                        <span className="text-indigo-300">{task.downloadSpeed}</span>
                      )}
                      <span className="text-slate-500 truncate max-w-[200px]">
                        {saveDirPath}{task.fileName}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Status & Badges */}
                <div className="flex items-center gap-2 w-full sm:w-auto justify-between sm:justify-end flex-wrap">
                  {statusBadge}
                  {/* Retry / Re-download single volume button - available anytime task is not actively downloading */}
                  {!isTaskActive && !isRetrying && (
                    <button
                      onClick={async () => {
                        updateTaskStateById(task.id, { status: 'idle', errorMessage: undefined });
                        setIsRunning(true);
                        isRunningRef.current = true;
                        inProgressTaskIdsRef.current.add(task.id);
                        await executeTask(task, 1);
                        inProgressTaskIdsRef.current.delete(task.id);
                        if (isRunningRef.current) {
                          const remaining = tasksRef.current.filter((t) => selectedTaskIds.has(t.id) && t.status !== 'completed').length;
                          if (remaining === 0) {
                            setIsRunning(false);
                            isRunningRef.current = false;
                          }
                        }
                      }}
                      className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-sm transition-all cursor-pointer ${
                        isFailed
                          ? 'bg-amber-900/80 hover:bg-amber-800 text-amber-200 border border-amber-600'
                          : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
                      }`}
                      title={isFailed ? "この巻を再試行" : "この巻を再ダウンロード"}
                    >
                      <RotateCcw className={`w-3.5 h-3.5 ${isFailed ? 'text-amber-400' : 'text-slate-400'}`} />
                      <span className="text-[11px]">{isFailed ? '再試行' : '再取得'}</span>
                    </button>
                  )}

                  {/* Immediate PC Save Button */}
                  {(task.directUrl || isCompleted || task.hasBlob || !!getBlobFromCache(task.id, task.fileName).blob) && (
                    <div className="flex items-center gap-1.5">
                      <button
                        id={`btn-save-pc-${task.id}`}
                        onClick={() => handleSaveSingleTask(task)}
                        disabled={savingTaskId === task.id}
                        className={`px-3 py-1.5 rounded-lg text-xs font-black flex items-center gap-1.5 shadow-md transition-all cursor-pointer ${
                          savingTaskId === task.id
                            ? 'bg-emerald-800 text-emerald-200 cursor-not-allowed opacity-90'
                            : dirHandle
                            ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-950'
                            : 'bg-emerald-400 hover:bg-emerald-300 text-slate-950 shadow-emerald-950 animate-bounce'
                        }`}
                        title="PCのダウンロードフォルダに直接保存 (別タブは開きません)"
                      >
                        {savingTaskId === task.id ? (
                          <>
                            <RotateCcw className="w-3.5 h-3.5 animate-spin" />
                            <span>PC保存中...</span>
                          </>
                        ) : dirHandle ? (
                          <>
                            <FolderDown className="w-3.5 h-3.5" />
                            <span>💾 フォルダへ保存</span>
                          </>
                        ) : (
                          <>
                            <Download className="w-3.5 h-3.5" />
                            <span>💾 今すぐPC保存</span>
                          </>
                        )}
                      </button>

                      {task.directUrl && (
                        <button
                          onClick={() => handleSaveSingleTask(task)}
                          disabled={savingTaskId === task.id}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs border border-slate-700 transition-colors cursor-pointer"
                          title="PCダウンロード保存 (別タブは開きません)"
                        >
                          <Download className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* Progress bar per item during operation */}
              {(isTaskActive || isRetrying) && (
                <div className="mt-2.5 pt-2 border-t border-slate-800/60">
                  <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                    <div
                      className={`h-full transition-all duration-300 ${
                        isDownloading
                          ? 'bg-teal-400'
                          : isAuth
                          ? 'bg-indigo-400'
                          : 'bg-amber-400'
                      }`}
                      style={{ width: `${task.progress}%` }}
                    />
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Folder Selection & Save Guide Modal */}
      {showFolderModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border-2 border-amber-500 rounded-2xl max-w-lg w-full p-6 shadow-2xl text-slate-100 animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <div className="flex items-center gap-2 text-amber-400 font-bold text-base">
                <Folder className="w-5 h-5 fill-amber-400 text-slate-900" />
                <span>保存先フォルダ指定（DL-RAW自動作成）について</span>
              </div>
              <button
                onClick={() => setShowFolderModal(false)}
                className="text-slate-400 hover:text-white text-lg font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4 text-xs leading-relaxed text-slate-300">
              <div className="bg-amber-950/60 border border-amber-700/60 rounded-xl p-3 text-amber-200">
                <p className="font-bold text-amber-100 mb-1">⚠️ 埋め込み画面（iframe）での動作制限について</p>
                <p>
                  ブラウザ（Chrome / Edge）のセキュリティ仕様により、埋め込みプレビュー画面（iframe）内からのPCフォルダ選択ダイアログの起動（File System Access API）は安全のため禁止されています（バグではなくブラウザの保護機能です）。
                </p>
              </div>

              <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-2">
                <div className="font-bold text-white text-sm flex items-center gap-1.5 text-emerald-400">
                  <span>✨ 解決策 1: 「別タブで開く」を利用する (推奨)</span>
                </div>
                <p className="text-slate-300">
                  下のボタンから別タブ（通常の独立したWebタブ）として開くと、ブラウザのフォルダ選択ダイアログが正常に起動します。
                  PC上の任意のフォルダ（例: <code className="bg-slate-800 px-1 py-0.5 rounded text-amber-300 font-mono">C:\Users\...\Downloads</code>）を指定するだけで、その配下に <strong className="text-emerald-300">DL-RAW/{displayTitle}/</strong> フォルダが自動生成され、全巻が直接保存されます！
                </p>
              </div>

              <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-2">
                <div className="font-bold text-white text-sm flex items-center gap-1.5 text-indigo-400">
                  <span>💾 解決策 2: この画面のまま保存する</span>
                </div>
                <p className="text-slate-300">
                  フォルダ指定を行わなくても、各巻の「<strong className="text-white">💾 今すぐPC保存</strong>」や上部の「<strong className="text-white">📦 完了全巻を1つのZIPでPC保存</strong>」ボタンを押せば、PCの標準保存先（<code className="bg-slate-800 px-1 py-0.5 rounded text-amber-300 font-mono">C:\Users\[ユーザー名]\Downloads</code>）に確実に保存されます（ブラウザのダウンロード履歴 <kbd className="px-1 py-0.5 bg-slate-800 border border-slate-700 rounded text-amber-300 font-mono">Ctrl + J</kbd> にも表示されます）。
                </p>
              </div>
            </div>

            <div className="mt-6 flex flex-col sm:flex-row items-center justify-end gap-2.5">
              <button
                onClick={() => setShowFolderModal(false)}
                className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold cursor-pointer"
              >
                この画面のまま進める
              </button>
              <button
                onClick={() => setShowFolderModal(false)}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-extrabold flex items-center justify-center gap-2 shadow-lg shadow-amber-500/25 transition-all cursor-pointer"
              >
                <span>了解（標準「ダウンロード」フォルダへ保存する）</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Real-time Download Toast Notification */}
      {downloadToast && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 border-2 border-emerald-500 text-white p-4 rounded-xl shadow-2xl flex items-start gap-3 max-w-md animate-in slide-in-from-bottom duration-300">
          <CheckCircle2 className="w-6 h-6 text-emerald-400 flex-shrink-0 mt-0.5" />
          <div className="flex-1 text-xs">
            <div className="font-bold text-sm text-emerald-300 mb-1">
              {downloadToast.isZip ? '📦 全巻一括ZIPのPC保存を開始しました！' : '💾 ファイルのPC保存を開始しました！'}
            </div>
            <p className="font-mono text-slate-200 mb-1.5 break-all font-semibold">{downloadToast.fileName}</p>
            <div className="text-slate-300 leading-relaxed bg-slate-950/80 p-2.5 rounded-lg border border-slate-800">
              <p className="font-semibold text-amber-300 mb-0.5">📂 保存場所: PCの「ダウンロード」フォルダ</p>
              <p className="text-[11px] text-slate-400">
                ブラウザで <kbd className="px-1.5 py-0.5 bg-slate-800 border border-slate-600 rounded text-amber-300 font-mono font-bold">Ctrl + J</kbd> を押すと、ダウンロード履歴と保存ファイルを確認できます。
              </p>
            </div>
          </div>
          <button
            onClick={() => setDownloadToast(null)}
            className="text-slate-400 hover:text-white p-1 text-xs cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}
    </div>
  );
};

