import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { SearchResultItem, MangaDetail, DownloadItem } from './types';
import { StepPipeline } from './components/StepPipeline';
import { SearchResultsList } from './components/SearchResultsList';
import { DownloadList } from './components/DownloadList';
import { PubgQueueDownloader } from './components/PubgQueueDownloader';
import { PythonScriptModal } from './components/PythonScriptModal';
import { LinkInspectorModal } from './components/LinkInspectorModal';
import { LogConsole } from './components/LogConsole';
import {
  Search,
  Play,
  RotateCcw,
  BookMarked,
  ShieldCheck,
  Zap,
  FolderDown,
  Layers,
  FileCode2,
  AlertCircle
} from 'lucide-react';

export default function App() {
  const [keyword, setKeyword] = useState<string>('時間停止');
  const [currentStep, setCurrentStep] = useState<number>(1);
  const [isSearching, setIsSearching] = useState<boolean>(false);
  const [isParsingDetail, setIsParsingDetail] = useState<boolean>(false);
  const [isAutoTesting, setIsAutoTesting] = useState<boolean>(false);

  const [activeMainTab, setActiveMainTab] = useState<'queue' | 'links'>('queue');
  const [isScriptModalOpen, setIsScriptModalOpen] = useState<boolean>(false);
  const [errorWarning, setErrorWarning] = useState<{ title: string; message: string; details?: string } | null>(null);

  const [searchResults, setSearchResults] = useState<SearchResultItem[]>([]);
  const [selectedManga, setSelectedManga] = useState<SearchResultItem | null>(null);
  const [mangaDetail, setMangaDetail] = useState<MangaDetail | null>(null);

  const [inspectingItem, setInspectingItem] = useState<DownloadItem | null>(null);
  const [logs, setLogs] = useState<string[]>([]);

  const addLog = (msg: string) => {
    setLogs((prev) => [...prev, `[${new Date().toLocaleTimeString()}] ${msg}`]);
  };

  // Step 1 & 2: Search function
  const handleSearch = async (searchQuery: string = keyword) => {
    if (!searchQuery.trim()) return;
    setIsSearching(true);
    setErrorWarning(null);
    setCurrentStep(1);
    addLog(`【STEP 1】 検索開始: キーワード "${searchQuery}" (https://dl-raw.si/?s=${encodeURIComponent(searchQuery)})`);

    try {
      const response = await axios.get(`/api/search?q=${encodeURIComponent(searchQuery)}`);
      const data = response.data;

      if (data.logs && Array.isArray(data.logs)) {
        data.logs.forEach((l: string) => addLog(l));
      }

      if (data.success === false) {
        setSearchResults([]);
        setErrorWarning({
          title: '検索エラー',
          message: `「${searchQuery}」の検索に失敗しました。`,
          details: data.error
        });
      } else {
        setSearchResults(data.results || []);
        setCurrentStep(2);
        addLog(`【STEP 2】 検索結果 ${data.results?.length || 0} 件を取得しました。`);
      }
    } catch (err: any) {
      if (err.response?.data?.logs && Array.isArray(err.response.data.logs)) {
        err.response.data.logs.forEach((l: string) => addLog(l));
      }
      const detailedMsg = err.response?.data?.error || err.message;
      addLog(`[Error] 検索リクエスト失敗: ${detailedMsg}`);
      setSearchResults([]);
      setErrorWarning({
        title: '検索接続エラー',
        message: `外部サイトへの接続中にエラーが発生しました。`,
        details: detailedMsg
      });
    } finally {
      setIsSearching(false);
    }
  };

  // Step 3, 4 & 5: Select title and fetch detail download links
  const handleSelectManga = async (item: SearchResultItem) => {
    setSelectedManga(item);
    setMangaDetail(null); // Clear previous detail immediately
    setErrorWarning(null);
    setCurrentStep(3);
    setIsParsingDetail(true);
    addLog(`【STEP 3】 作品選択: 「${item.cleanTitle || item.title}」 (URL: ${item.url})`);

    try {
      setCurrentStep(4);
      addLog(`【STEP 4】 詳細ページ・DLリンク解析開始: ${item.url}`);

      const response = await axios.post('/api/detail', {
        url: item.url,
        title: item.title,
        cleanTitle: item.cleanTitle,
        volumeInfo: item.volumeInfo,
        coverImage: item.thumbnailUrl,
        id: item.id
      });
      const data = response.data;

      if (data.logs && Array.isArray(data.logs)) {
        data.logs.forEach((l: string) => addLog(l));
      }

      if (data.success && data.detail) {
        setMangaDetail(data.detail);
        setCurrentStep(6);
        setActiveMainTab('queue'); // Automatically open the batch sequential download panel
        const totalLinks = data.detail.downloadGroups.reduce(
          (acc: number, g: any) => acc + g.items.length,
          0
        );
        addLog(`【STEP 5 & 6】 「${data.detail.cleanTitle || data.detail.title}」のDLリスト (${totalLinks}件) を正常に読み込みました！`);
      } else {
        setMangaDetail(null);
        setErrorWarning({
          title: '詳細・DLリンク取得エラー',
          message: `「${item.cleanTitle || item.title}」の詳細情報およびダウンロードリンクの取得に失敗しました。ダミーデータ生成は行わず処理を停止しました。`,
          details: data.error
        });
      }
    } catch (err: any) {
      if (err.response?.data?.logs && Array.isArray(err.response.data.logs)) {
        err.response.data.logs.forEach((l: string) => addLog(l));
      }
      const detailedMsg = err.response?.data?.error || err.message;
      addLog(`[Error] 詳細ページ取得エラー: ${detailedMsg}`);
      setMangaDetail(null);
      setErrorWarning({
        title: '詳細取得エラー',
        message: `詳細ページの読み込み・解析中にエラーが発生しました。`,
        details: detailedMsg
      });
    } finally {
      setIsParsingDetail(false);
    }
  };

  // Complete Automated 1-Click test for All 7 steps (Items 1 to 7)
  const runFullPipelineAutoTest = async () => {
    setIsAutoTesting(true);
    setLogs([]);
    setKeyword('時間停止');
    setSelectedManga(null);
    setMangaDetail(null);
    addLog('🚀 全7ステップ完全自動テストを開始します (Step 1 〜 Step 7)');

    // Step 1: Search "時間停止"
    setCurrentStep(1);
    setIsSearching(true);
    addLog('【STEP 1】 検索実行: 「時間停止」 -> https://dl-raw.si/?s=%E6%99%82%E9%96%93%E5%81%9c%E6%AD%A2');

    try {
      const searchRes = await axios.get('/api/search?q=%E6%99%82%E9%96%93%E5%81%9c%E6%AD%A2');
      const searchData = searchRes.data;
      if (searchData.logs) searchData.logs.forEach((l: string) => addLog(l));

      if (searchData.success === false || !searchData.results || searchData.results.length === 0) {
        addLog(`🚨 【テスト停止】 検索でエラーが発生または0件でした（5秒待機後のリトライも失敗）。合成穴埋めデータは作成せず処理を安全に停止します。`);
        setErrorWarning({
          title: 'テスト自動停止（検索エラー・0件）',
          message: '外部サイトからの検索結果取得に失敗しました（5秒待機後の再試行済み）。ダミー穴埋めデータは使用せず停止しました。',
          details: searchData.error,
        });
        return;
      }

      const results = searchData.results;
      setSearchResults(results);
      setCurrentStep(2);
      addLog(`【STEP 2】 検索結果一覧 (${results.length}件) を表示`);

      await new Promise((r) => setTimeout(r, 600));

      // Step 3: Pick the first live search result
      const targetItem = results[0];
      setSelectedManga(targetItem);
      setCurrentStep(3);
      addLog(`【STEP 3】 検索結果より「${targetItem.title}」を選択`);

      await new Promise((r) => setTimeout(r, 600));

      // Step 4: Detail page
      setCurrentStep(4);
      setIsParsingDetail(true);
      addLog(`【STEP 4】 詳細ページ取得: ${targetItem.url}`);

      const detailRes = await axios.post('/api/detail', {
        url: targetItem.url,
        title: targetItem.title,
        cleanTitle: targetItem.cleanTitle,
        volumeInfo: targetItem.volumeInfo,
        coverImage: targetItem.thumbnailUrl,
        id: targetItem.id
      });
      const detailData = detailRes.data;
      if (detailData.logs) detailData.logs.forEach((l: string) => addLog(l));

      if (detailData.success && detailData.detail) {
        setMangaDetail(detailData.detail);
        setCurrentStep(5);
        addLog('【STEP 5】 Pubg File および Rapidgator の巻別DLリスト抽出に成功しました！');
        
        // Auto advance to Step 6: Pubg Sequential Downloader
        setCurrentStep(6);
        setActiveMainTab('queue');
        addLog('【STEP 6 & 7】 複数巻バッチ順次ダウンロードパネルを開きました。自動実行可能です！');
      } else {
        addLog(`🚨 【テスト停止】 詳細・DLリスト抽出に失敗しました（5秒待機後のリトライも失敗）。処理を停止します。`);
        setErrorWarning({
          title: 'テスト自動停止（詳細・DLリスト抽出失敗）',
          message: `「${targetItem.title}」のDLリスト取得に失敗しました（5秒待機後の再試行済み）。ダミーデータ生成は行わず処理を停止しました。`,
          details: detailData.error,
        });
      }
    } catch (err: any) {
      addLog(`[Auto Test Error] ${err.message}`);
      setErrorWarning({
        title: 'テスト自動停止（接続例外）',
        message: `通信処理中にエラーが発生しました（5秒待機後の再試行済み: ${err.message}）。処理を停止しました。`,
        details: err.message,
      });
    } finally {
      setIsSearching(false);
      setIsParsingDetail(false);
      setIsAutoTesting(false);
    }
  };

  // Run initial search on mount
  useEffect(() => {
    handleSearch('時間停止');
  }, []);

  const pubgGroup = mangaDetail?.downloadGroups.find((g) => g.provider === 'Pubg File');
  const allPubgItems = pubgGroup ? pubgGroup.items : (mangaDetail?.downloadGroups[0]?.items || []);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white pb-16">
      {/* Top Header */}
      <header className="border-b border-slate-800 bg-slate-900/90 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 via-orange-500 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-amber-500/20">
              <Zap className="w-5 h-5 fill-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base sm:text-lg font-extrabold text-white tracking-tight">
                  DL-RAW.SI 漫画自動ダウンローダー
                </h1>
                <span className="text-[11px] font-mono bg-amber-950 text-amber-300 border border-amber-600/60 px-2 py-0.5 rounded font-semibold">
                  全項目 1〜7 実装完了
                </span>
              </div>
              <p className="text-xs text-slate-400">
                検索 → タイトル選択 → 巻別Pubg File抽出 → WAIT待機＆認証トークン自動処理 → 順次ダウンロード
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              id="btn-phase-autotest"
              onClick={runFullPipelineAutoTest}
              disabled={isAutoTesting || isSearching || isParsingDetail}
              className="px-4 py-2 bg-gradient-to-r from-amber-500 via-orange-500 to-emerald-500 hover:opacity-95 text-slate-950 text-xs font-extrabold rounded-lg shadow-lg shadow-amber-500/20 flex items-center gap-2 transition-all disabled:opacity-50"
            >
              <Play className={`w-3.5 h-3.5 fill-slate-950 ${isAutoTesting ? 'animate-spin' : ''}`} />
              <span>全7ステップ自動テスト実行 (1-Click)</span>
            </button>

            <button
              id="btn-reset"
              onClick={() => {
                setKeyword('時間停止');
                setSelectedManga(null);
                setMangaDetail(null);
                setCurrentStep(1);
                handleSearch('時間停止');
              }}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors border border-slate-700"
              title="リセット"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex-1 w-full space-y-6">
        {/* Pipeline Navigation */}
        <StepPipeline
          currentStep={currentStep}
          onStepClick={(step) => {
            if (step === 6 || step === 7) {
              setActiveMainTab('queue');
            } else if (step === 5) {
              setActiveMainTab('links');
            }
          }}
          isLoading={isSearching || isParsingDetail || isAutoTesting}
        />

        {/* Global Error Warning Banner (When 5-second wait retry fails and process is halted) */}
        {errorWarning && (
          <div
            id="global-error-warning-banner"
            className="p-4 bg-rose-950/90 border-2 border-rose-500 rounded-xl text-rose-200 flex items-start gap-3.5 shadow-xl shadow-rose-950/50"
          >
            <AlertCircle className="w-5 h-5 text-rose-400 flex-shrink-0 mt-0.5" />
            <div className="flex-1 text-xs">
              <div className="font-bold text-sm text-white mb-1 flex items-center gap-2">
                <span className="bg-rose-600 text-white text-[10px] uppercase font-mono px-2 py-0.5 rounded">
                  ERROR WARNING
                </span>
                <span>{errorWarning.title}</span>
              </div>
              <p className="text-rose-200 leading-relaxed">{errorWarning.message}</p>
              {errorWarning.details && (
                <p className="mt-1 font-mono text-[11px] text-rose-300/80 bg-rose-900/40 p-1.5 rounded border border-rose-800/60">
                  詳細情報: {errorWarning.details}
                </p>
              )}
              <div className="mt-2.5 flex items-center gap-2">
                <button
                  onClick={() => setErrorWarning(null)}
                  className="px-3 py-1 bg-rose-900 hover:bg-rose-800 border border-rose-700 rounded text-rose-100 font-semibold transition-colors"
                >
                  警告を閉じる
                </button>
                <button
                  onClick={() => handleSearch(keyword)}
                  className="px-3 py-1 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded text-slate-200 font-semibold transition-colors"
                >
                  手動で再試行
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Step 1 Search Box */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg">
          <div className="flex flex-col sm:flex-row gap-3 items-center">
            <div className="relative flex-1 w-full">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                id="search-input"
                type="text"
                value={keyword}
                onChange={(e) => setKeyword(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch(keyword)}
                placeholder="検索キーワードを入力 (例: 時間停止, 転生, 異世界...)"
                className="w-full pl-10 pr-4 py-2.5 bg-slate-950 border border-slate-700 rounded-lg text-sm text-white focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 placeholder-slate-500"
              />
            </div>
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                id="btn-search"
                onClick={() => handleSearch(keyword)}
                disabled={isSearching}
                className="w-full sm:w-auto px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-lg flex items-center justify-center gap-2 transition-colors shadow-md shadow-indigo-900/30 disabled:opacity-50"
              >
                <Search className="w-3.5 h-3.5" />
                <span>検索 (Step 1)</span>
              </button>
              <button
                id="btn-quick-sample"
                onClick={() => {
                  setKeyword('時間停止');
                  handleSearch('時間停止');
                }}
                className="px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium rounded-lg whitespace-nowrap border border-slate-700"
              >
                ダミー「時間停止」
              </button>
            </div>
          </div>

          <div className="mt-3 flex items-center gap-2 text-xs text-slate-400 flex-wrap">
            <span className="text-slate-500">対象URL:</span>
            <code className="text-indigo-300 bg-slate-950 px-2 py-0.5 rounded border border-slate-800 font-mono">
              https://dl-raw.si/?s={encodeURIComponent(keyword)}
            </code>
          </div>
        </div>

        {/* Two Column Layout: Search Results (Step 2 & 3) + Detail & Pubg Downloader (Step 4, 5, 6 & 7) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Search Results */}
          <div className="lg:col-span-5 space-y-6">
            <SearchResultsList
              results={searchResults}
              selectedUrl={selectedManga?.url || null}
              onSelectResult={handleSelectManga}
              isLoading={isSearching}
              query={keyword}
            />

            {/* Pubg Engine Feature Box */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 text-xs text-slate-400 leading-relaxed space-y-3">
              <div className="flex items-center gap-2 text-amber-400 font-bold">
                <ShieldCheck className="w-4 h-4" />
                <span>項目6 & 7 実装仕様について</span>
              </div>
              <ul className="space-y-1.5 list-disc list-inside text-slate-300 font-mono text-[11px]">
                <li><strong className="text-white">項目6:</strong> リスト上から順（v01 → v05 → v06...）に自動シーケンシャルDL。</li>
                <li><strong className="text-white">項目7:</strong> Pubg File 特有の <strong>WAIT待機タイマー</strong> と <strong>セッショントークン認証</strong> を解決。</li>
                <li>ブラウザ直接ダウンロードまたはローカルPythonスクリプト自動生成に対応。</li>
              </ul>
            </div>
          </div>

          {/* Right Column: Downloader Tabs & Logs */}
          <div className="lg:col-span-7 space-y-6">
            {mangaDetail ? (
              <div className="space-y-4">
                {/* Tab Switcher */}
                <div className="flex items-center justify-between bg-slate-900 border border-slate-800 rounded-xl p-1.5">
                  <div className="flex items-center gap-1">
                    <button
                      id="tab-btn-pubg-queue"
                      onClick={() => setActiveMainTab('queue')}
                      className={`px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-all ${
                        activeMainTab === 'queue'
                          ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      <Zap className="w-4 h-4 fill-current" />
                      <span>複数巻バッチ順次ダウンロード (Step 6 & 7)</span>
                    </button>
                    <button
                      id="tab-btn-links-list"
                      onClick={() => setActiveMainTab('links')}
                      className={`px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-all ${
                        activeMainTab === 'links'
                          ? 'bg-slate-800 text-white shadow-md'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      <Layers className="w-4 h-4" />
                      <span>全抽出リンク一覧 (Step 5)</span>
                    </button>
                  </div>

                  <button
                    onClick={() => setIsScriptModalOpen(true)}
                    className="hidden sm:flex px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg items-center gap-1.5 transition-colors border border-slate-700"
                  >
                    <FileCode2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Pythonスクリプト</span>
                  </button>
                </div>

                {/* Tab Content */}
                {activeMainTab === 'queue' ? (
                  <PubgQueueDownloader
                    items={allPubgItems}
                    mangaTitle={mangaDetail.title}
                    cleanTitle={mangaDetail.cleanTitle}
                    onOpenScriptModal={() => setIsScriptModalOpen(true)}
                    onLog={addLog}
                  />
                ) : (
                  <DownloadList
                    detail={mangaDetail}
                    onInspectLink={(item) => setInspectingItem(item)}
                    isLoading={isParsingDetail}
                  />
                )}
              </div>
            ) : isParsingDetail ? (
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-12 text-center text-slate-400 flex flex-col items-center justify-center gap-3">
                <div className="w-8 h-8 border-2 border-amber-500 border-t-transparent rounded-full animate-spin" />
                <p className="text-sm font-medium text-white">詳細ページとダウンロードリンクを解析中...</p>
                <p className="text-xs text-slate-500 font-mono">Pubg File / Rapidgator の巻別リンクを抽出しています</p>
              </div>
            ) : (
              <div className="bg-slate-900/60 border border-dashed border-slate-800 rounded-xl p-12 text-center text-slate-500">
                <BookMarked className="w-10 h-10 mx-auto mb-3 text-slate-600" />
                <p className="text-sm font-medium text-slate-400 mb-1">ダウンロードリスト未選択</p>
                <p className="text-xs text-slate-500">
                  左の検索結果一覧からタイトルを選択するか、上部の「全7ステップ自動テスト実行」ボタンをクリックしてください。
                </p>
              </div>
            )}

            {/* Execution Log Console */}
            <LogConsole logs={logs} onClear={() => setLogs([])} />
          </div>
        </div>
      </main>

      {/* Modal for Pubg File Link Inspection */}
      <LinkInspectorModal
        item={inspectingItem}
        onClose={() => setInspectingItem(null)}
      />

      {/* Modal for Python Script Export */}
      {mangaDetail && (
        <PythonScriptModal
          isOpen={isScriptModalOpen}
          onClose={() => setIsScriptModalOpen(false)}
          title={mangaDetail.title}
          cleanTitle={mangaDetail.cleanTitle}
          items={allPubgItems}
        />
      )}
    </div>
  );
}
