import express from "express";
import path from "path";
import fs from "fs";
import http from "http";
import https from "https";
import axios from "axios";
import * as cheerio from "cheerio";
import JSZip from "jszip";
import { createServer as createViteServer } from "vite";

const keepAliveHttpAgent = new http.Agent({
  keepAlive: true,
  keepAliveMsecs: 1000,
  maxSockets: 100
});

const keepAliveHttpsAgent = new https.Agent({
  keepAlive: true,
  keepAliveMsecs: 1000,
  maxSockets: 100,
  rejectUnauthorized: false
});

const app = express();
const PORT = 3000;

app.use(express.json());

// Health check endpoint
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// Cleans manga titles removing "raw", volume indicators, etc.
function cleanMangaTitle(rawTitle: string): string {
  if (!rawTitle) return "";
  let title = rawTitle;

  // Remove bracket tags like [raw], 【一般コミック】, [DL版], etc.
  title = title.replace(/[\[\(【]\s*(?:raw|RAW|DL版|一般コミック|コミック|雑誌|完|DL-RAW|zip|rar)\s*[\]\)】]/gi, " ");

  // Remove standalone "raw", "RAW"
  title = title.replace(/\b(?:raw|RAW|Raw)\b/gi, " ");

  // Remove volume or chapter range like 第01-22巻, 第01～22巻, 第1-15巻, 第1-3話, 第01巻, [第01-22巻], (第01-22巻)
  title = title.replace(/[\[\(【]?\s*第?\s*\d+\s*[-~～〜–]\s*\d+\s*(?:巻|話)?\s*[\]\)】]?/g, " ");
  title = title.replace(/[\[\(【]?\s*第\s*\d+\s*(?:巻|話)\s*[\]\)】]?/g, " ");
  title = title.replace(/[\[\(【]?\s*\d+\s*(?:巻|話)\s*[\]\)】]?/g, " ");

  // Remove vol.01-15, vol 01, v01-v22, etc.
  title = title.replace(/[\[\(【]?\s*vol(?:ume)?\.?\s*\d*(?:\s*[-~～〜–]\s*\d+)?\s*[\]\)】]?/gi, " ");
  title = title.replace(/[\[\(【]?\s*v\d+(?:\s*[-~～〜–]\s*v?\d+)?\s*[\]\)】]?/gi, " ");

  // Remove any remaining bracketed numbers like [1-10]
  title = title.replace(/[\[\(【]\s*\d+\s*[-~～〜–]\s*\d+\s*[\]\)】]/g, " ");

  // Clean trailing/leading dashes, underscores, colons, lone tags
  title = title.replace(/^[\s\-–—_:]+|[\s\-–—_:]+$/g, "");
  // Normalize whitespaces
  title = title.replace(/\s+/g, " ").trim();

  return title || rawTitle;
}

// Extracts volume range (e.g., 第01-22巻)
function extractVolumeRange(rawTitle: string): string | null {
  if (!rawTitle) return null;
  const match1 = rawTitle.match(/[\[\(【]?\s*(第\s*\d+\s*[-~～〜–]\s*\d+\s*巻)\s*[\]\)】]?/i);
  if (match1) return match1[1].replace(/\s+/g, "");
  const match2 = rawTitle.match(/[\[\(【]?\s*(第\s*\d+\s*巻)\s*[\]\)】]?/i);
  if (match2) return match2[1].replace(/\s+/g, "");
  const match3 = rawTitle.match(/[\[\(【]?\s*(第\s*\d+(?:\s*[-~～〜–]\s*\d+)?\s*話)\s*[\]\)】]?/i);
  if (match3) return match3[1].replace(/\s+/g, "");
  const match4 = rawTitle.match(/[\[\(【]?\s*(\d+\s*[-~～〜–]\s*\d+\s*巻)\s*[\]\)】]?/i);
  if (match4) return match4[1].replace(/\s+/g, "");
  const match5 = rawTitle.match(/[\[\(【]?\s*(vol(?:ume)?\.?\s*\d+(?:\s*[-~～〜–]\s*\d+)?)\s*[\]\)】]?/i);
  if (match5) return match5[1].trim();
  const match6 = rawTitle.match(/[\[\(【]?\s*(v\d+(?:\s*[-~～〜–]\s*v?\d+)?)\s*[\]\)】]?/i);
  if (match6) return match6[1].trim();
  const match7 = rawTitle.match(/[\[\(【]\s*(\d+\s*[-~～〜–]\s*\d+)\s*[\]\)】]/);
  if (match7) return `第${match7[1].replace(/\s+/g, "")}巻`;
  return null;
}

// Standard realistic User-Agent headers to avoid simple bot blocks
const DEFAULT_HEADERS = {
  "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
  "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
  "Accept-Language": "ja,en-US;q=0.9,en;q=0.8",
  "Cache-Control": "no-cache",
  "Pragma": "no-cache",
  "Sec-Ch-Ua": '"Google Chrome";v="123", "Not:A-Brand";v="8", "Chromium";v="123"',
  "Sec-Ch-Ua-Mobile": "?0",
  "Sec-Ch-Ua-Platform": '"Windows"',
  "Sec-Fetch-Dest": "document",
  "Sec-Fetch-Mode": "navigate",
  "Sec-Fetch-Site": "none",
  "Sec-Fetch-User": "?1",
  "Upgrade-Insecure-Requests": "1"
};

// Helper to fetch with 5-second WAIT and 1 retry on error, logging every step
async function fetchWithRetry(url: string, options: any, logs: string[]): Promise<any> {
  try {
    const res = await axios.get(url, {
      ...options,
      headers: {
        ...DEFAULT_HEADERS,
        ...(options.headers || {})
      },
      timeout: options.timeout || 10000
    });
    return res;
  } catch (err: any) {
    logs.push(`[Wait & Retry] 外部通信エラー発生 (${err.message})。5秒待機してリトライを実行します...`);
    // 5-second WAIT
    await new Promise((resolve) => setTimeout(resolve, 5000));

    try {
      logs.push(`[Retry] 5秒経過。再試行を実行中: ${url}`);
      const retryRes = await axios.get(url, {
        ...options,
        headers: {
          ...DEFAULT_HEADERS,
          ...(options.headers || {})
        },
        timeout: options.timeout || 12000
      });
      logs.push(`[Retry Success] リトライ成功 (Status: ${retryRes.status})`);
      return retryRes;
    } catch (retryErr: any) {
      logs.push(`[Error Warning] 🚨 5秒待機後のリトライにも失敗しました (${retryErr.message})。ダミーデータや穴埋め合成は行わず、処理を停止します。`);
      throw retryErr;
    }
  }
}

// 1. Search API endpoint
app.get("/api/search", async (req, res) => {
  const query = (req.query.q as string) || "時間停止";
  const searchUrl = `https://dl-raw.si/?s=${encodeURIComponent(query)}`;

  const logs: string[] = [];
  logs.push(`[Step 1] 検索リクエスト開始: "${query}" -> ${searchUrl}`);

  try {
    const startTime = Date.now();
    const response = await fetchWithRetry(searchUrl, { Referer: "https://dl-raw.si/" }, logs);

    const elapsed = Date.now() - startTime;
    logs.push(`[Step 1] レスポンス取得成功 (${elapsed}ms, Status: ${response.status})`);

    const html = response.data;
    const $ = cheerio.load(html);
    const results: any[] = [];

    // Parse WordPress post cards / entries
    $("article, .post, .entry, .search-result, .type-post").each((i, el) => {
      const titleEl = $(el).find("h2.entry-title a, h2 a, h3 a, .post-title a, a[rel='bookmark']").first();
      let title = titleEl.text().trim();
      let link = titleEl.attr("href") || "";

      if (!link) {
        const anyLink = $(el).find("a").first();
        link = anyLink.attr("href") || "";
        if (!title) title = anyLink.text().trim() || anyLink.attr("title") || "";
      }

      if (title && link && !link.includes("/category/") && !link.includes("/tag/")) {
        const imgEl = $(el).find("img").first();
        const thumb = imgEl.attr("src") || imgEl.attr("data-src") || "";
        const date = $(el).find("time, .post-date, .entry-date").first().text().trim();
        const snippet = $(el).find(".entry-summary, .post-excerpt, p").first().text().trim();

        results.push({
          id: `live-${i + 1}`,
          title,
          cleanTitle: cleanMangaTitle(title),
          volumeInfo: extractVolumeRange(title) || undefined,
          url: link,
          thumbnailUrl: thumb || undefined,
          date: date || undefined,
          snippet: snippet || undefined
        });
      }
    });

    logs.push(`[Step 2] HTMLパース完了: ${results.length} 件の記事を発見`);

    if (results.length > 0) {
      return res.json({
        success: true,
        source: "live",
        query,
        targetUrl: searchUrl,
        results,
        logs
      });
    } else {
      logs.push(`[Step 2] 検索結果は0件でした（該当記事なし）。ダミーデータによる穴埋めは行いません。`);
      return res.json({
        success: true,
        source: "live_empty",
        query,
        targetUrl: searchUrl,
        results: [],
        message: `「${query}」に一致する記事は見つかりませんでした。`,
        logs
      });
    }
  } catch (err: any) {
    logs.push(`[Error Warning] 検索処理を停止しました: ${err.message}`);
    return res.status(502).json({
      success: false,
      error: `外部サイト(dl-raw.si)の検索に失敗しました（5秒待機後の再試行も接続不能: ${err.message}）。`,
      query,
      targetUrl: searchUrl,
      results: [],
      logs
    });
  }
});

// Helper to extract volume or chapter label
function extractVolumeLabel(fileName: string, idx: number): string {
  if (!fileName) return `Part ${idx + 1}`;
  
  // Chapter format: ch01-02a, ch3, ch03, 第1-3話, 1話
  const chMatch = fileName.match(/(?:ch|chapter|第)\s*(\d+(?:[-~～〜–]\d+)?\s*[a-z]?)\s*話?/i);
  if (chMatch) {
    return `第${chMatch[1].trim()}話`;
  }
  
  // Volume format: v01, vol.02, 第01-22巻, 01-22巻
  const volMatch = fileName.match(/(?:v|vol(?:ume)?\.?|第)\s*(\d+(?:[-~～〜–]\d+)?)\s*巻?/i);
  if (volMatch) {
    return `第${volMatch[1].trim()}巻`;
  }

  // Any number range like 01-22
  const numMatch = fileName.match(/(\d+(?:[-~～〜–]\d+)?)/);
  if (numMatch) {
    return `Part ${numMatch[1]}`;
  }

  return `Part ${idx + 1}`;
}

// Extracts numeric volume/chapter number for descending sorting
function extractVolumeNumber(fileName: string, label?: string): number {
  const text = `${label ? label + ' ' : ''}${fileName || ''}`;
  const rangeMatch = text.match(/(?:第|v|vol(?:ume)?\.?|ch(?:apter)?)?\s*(\d+)\s*[-~～〜–]\s*(\d+)/i);
  if (rangeMatch) return parseFloat(rangeMatch[2]);
  const volMatch = text.match(/(?:v|vol(?:ume)?\.?|第|ch(?:apter)?)\s*(\d+(?:\.\d+)?)/i);
  if (volMatch) return parseFloat(volMatch[1]);
  const partMatch = text.match(/Part\s*(\d+)/i);
  if (partMatch) return parseFloat(partMatch[1]);
  const numMatch = text.match(/(\d+)/);
  if (numMatch) return parseFloat(numMatch[1]);
  return 0;
}

// 2. Detail API endpoint
app.post("/api/detail", async (req, res) => {
  const { url } = req.body;
  if (!url) {
    return res.status(400).json({ error: "url is required" });
  }

  const logs: string[] = [];
  logs.push(`[Step 4] 詳細ページ取得開始: ${url}`);

  try {
    const startTime = Date.now();
    const response = await fetchWithRetry(url, { Referer: "https://dl-raw.si/" }, logs);

    const elapsed = Date.now() - startTime;
    logs.push(`[Step 4] 詳細ページHTML取得成功 (${elapsed}ms, Status: ${response.status})`);

    const html = response.data;
    const $ = cheerio.load(html);

    const title = $("h1.entry-title, h1.post-title, article h1, h1").first().text().trim() || "";
    const coverImage = $(".content-text img, .entry-content img, .post-thumbnail img, article img").first().attr("src");
    const description = $(".content-text p, .entry-content p, article p").first().text().trim() || "";

    if (!title) {
      logs.push(`[Error Warning] タイトル情報が見つかりません。`);
      return res.status(404).json({
        success: false,
        error: "詳細ページからタイトルを抽出できませんでした。",
        logs
      });
    }

    // Parse download links and group by provider
    const downloadGroupsMap: { [provider: string]: any[] } = {};

    // Check all anchor links inside the article / content areas
    $("article a, .content-text a, .entry-content a, main a").each((idx, aEl) => {
      const href = $(aEl).attr("href");
      if (!href) return;

      let linkText = $(aEl).text().trim();
      const parentText = $(aEl).parent().text().trim();

      // Determine provider from link URL or parent section text
      let provider: string | null = null;
      if (href.includes("leechtop") || href.includes("pubgfile")) {
        provider = "Pubg File";
      } else if (href.includes("rapidgator")) {
        provider = "Rapidgator";
      } else if (href.includes("mexashare") || href.includes("mexa.sh")) {
        provider = "Mexashare";
      } else if (href.includes("katfile")) {
        provider = "Katfile";
      } else if (/pubg/i.test(parentText)) {
        provider = "Pubg File";
      } else if (/rapidgator/i.test(parentText)) {
        provider = "Rapidgator";
      }

      if (
        provider &&
        (href.startsWith("http") || href.startsWith("//")) &&
        !href.includes("/category/") &&
        !href.includes("/tag/") &&
        !href.includes("rawfree") &&
        !href.startsWith("#")
      ) {
        // Extract size
        let size: string | undefined = undefined;
        const sizeMatch =
          linkText.match(/[–—\-]\s*([\d\.]+\s*(?:MB|GB|KB|TB))/i) ||
          parentText.match(/[–—\-]\s*([\d\.]+\s*(?:MB|GB|KB|TB))/i);

        if (sizeMatch) {
          size = sizeMatch[1].trim();
          linkText = linkText.replace(/[–—\-]\s*[\d\.]+\s*(?:MB|GB|KB|TB)/i, "").trim();
        }

        const fileName = linkText || `Download ${idx + 1}`;
        const volumeLabel = extractVolumeLabel(fileName, idx);
        const ext = fileName.endsWith(".zip") ? "zip" : "rar";

        if (!downloadGroupsMap[provider]) {
          downloadGroupsMap[provider] = [];
        }

        // Deduplicate by URL
        if (!downloadGroupsMap[provider].some(item => item.url === href)) {
          downloadGroupsMap[provider].push({
            id: `dl-${provider.toLowerCase().replace(/\s+/g, "_")}-${downloadGroupsMap[provider].length + 1}`,
            fileName,
            volumeLabel,
            size,
            url: href,
            provider,
            extension: ext
          });
        }
      }
    });

    const downloadGroups = Object.keys(downloadGroupsMap).map(provider => {
      const groupItems = [...downloadGroupsMap[provider]];
      // Sort in descending order (降順表示: latest volumes first, e.g. v22, v21, ... v01)
      groupItems.sort((a, b) => extractVolumeNumber(b.fileName, b.volumeLabel) - extractVolumeNumber(a.fileName, a.volumeLabel));
      return {
        provider,
        items: groupItems
      };
    });

    if (downloadGroups.length > 0) {
      logs.push(`[Step 5] ライブHTMLから抽出完了: プロバイダー ${downloadGroups.length} 件、合計リンク ${downloadGroups.reduce((acc, g) => acc + g.items.length, 0)} 件`);
      return res.json({
        success: true,
        source: "live",
        detail: {
          title,
          cleanTitle: cleanMangaTitle(title),
          url,
          coverImage,
          description,
          downloadGroups
        },
        logs
      });
    } else {
      logs.push(`[Error Warning] 🚨 ページ内にダウンロードリンク（Pubg File等）が見つかりませんでした。穴埋め合成は行わず処理を停止します。`);
      return res.status(422).json({
        success: false,
        error: "ページ内に有効なダウンロードリンク（Pubg File / Rapidgator等）が見つかりませんでした。",
        logs
      });
    }
  } catch (err: any) {
    logs.push(`[Error Warning] 🚨 詳細ページの取得・パースに失敗しました（5秒待機後リトライ済み: ${err.message}）。処理を停止します。`);
    return res.status(502).json({
      success: false,
      error: `詳細ページの取得に失敗しました（5秒待機後の再試行も接続不能: ${err.message}）。`,
      logs
    });
  }
});

// 3. Inspect Download Link (Pubg File / Rapidgator diagnostic)
app.post("/api/inspect-link", async (req, res) => {
  const { url, provider } = req.body;
  if (!url) {
    return res.status(400).json({ error: "url is required" });
  }

  const logs: string[] = [];
  logs.push(`[Inspection] リンク検査開始: ${url} (Provider: ${provider || "Unknown"})`);

  try {
    const startTime = Date.now();
    const response = await axios.get(url, {
      headers: {
        ...DEFAULT_HEADERS,
        Referer: "https://dl-raw.si/"
      },
      timeout: 10000,
      maxRedirects: 5,
      validateStatus: () => true // accept all status codes for diagnosis
    });
    const elapsed = Date.now() - startTime;

    const html = typeof response.data === "string" ? response.data : "";
    const $ = cheerio.load(html);

    // Look for common file hosting elements: timers, countdowns, captcha, buttons
    const pageTitle = $("title").text().trim();
    const hasCaptcha = /captcha|turnstile|recaptcha|hcaptcha/i.test(html);
    const hasTimer = /countdown|seconds|waiting|timer|wait\s*\d+/i.test(html);
    const downloadButtons: string[] = [];

    $("a, button, input[type='submit']").each((_, el) => {
      const text = $(el).text().trim() || $(el).attr("value") || "";
      if (/download|free download|slow download|get file|create download link/i.test(text)) {
        downloadButtons.push(text);
      }
    });

    logs.push(`[Inspection] HTTP Status: ${response.status} (${elapsed}ms)`);
    logs.push(`[Inspection] ページタイトル: "${pageTitle}"`);
    logs.push(`[Inspection] 認証/Captcha検出: ${hasCaptcha ? "有り (要検証/対応)" : "検出なし"}`);
    logs.push(`[Inspection] 待機タイマー検出: ${hasTimer ? "有り (カウントダウン待機必要)" : "即時または未検出"}`);
    logs.push(`[Inspection] アクションボタン: ${downloadButtons.join(", ") || "直接ダウンロードリンクまたはJavaScript生成"}`);

    return res.json({
      success: true,
      statusCode: response.status,
      elapsedMs: elapsed,
      pageTitle,
      hasCaptcha,
      hasTimer,
      downloadButtons,
      headers: response.headers,
      logs
    });
  } catch (err: any) {
    logs.push(`[Inspection Error] ${err.message}`);
    return res.json({
      success: false,
      error: err.message,
      logs,
      simulatedAnalysis: {
        provider: provider || "Pubg File",
        note: "Pubg File は通常 10〜30 秒の待機カウントダウン、CSRFトークン検証、およびブラウザフィンガープリント等の認証ステップを経てダイレクトダウンロードURLが発行されます。"
      }
    });
  }
});

// 4. Resolve Pubg Direct Download (Real Page Analysis & Auth Resolution)
app.post("/api/pubg/resolve-download", async (req, res) => {
  const { url, fileName, fastMode } = req.body;
  const logs: string[] = [];

  if (!url) {
    return res.status(400).json({ error: "url is required" });
  }

  logs.push(`[Pubg Engine] リクエスト受信: ${fileName || "ファイル"} (${url})`);

  try {
    // Step 1: Request the landing page (Leechtop / Pubg file landing)
    logs.push(`[Pubg Engine] 1. ランディングページへアクセス中: ${url}`);
    const pageRes = await axios.get(url, {
      headers: {
        ...DEFAULT_HEADERS,
        Referer: "https://dl-raw.si/"
      },
      timeout: 15000,
      maxRedirects: 5
    });

    const html = typeof pageRes.data === "string" ? pageRes.data : "";
    const cookies = (pageRes.headers["set-cookie"] || []).map(c => c.split(";")[0]).join("; ");

    // Step 2: Parse page metadata, timer, and AJAX parameters
    const nonceMatch = html.match(/"nonce":"([^"]+)"/);
    const nonce = nonceMatch ? nonceMatch[1] : null;
    const ajaxUrlMatch = html.match(/"ajax_url":"([^"]+)"/);
    const ajaxUrl = ajaxUrlMatch ? ajaxUrlMatch[1].replace(/\\\//g, "/") : "https://leechtop.com/wp-admin/admin-ajax.php";

    const pMatch = html.match(/data-p="([^"]+)"/);
    const p = pMatch ? pMatch[1] : null;
    const mbMatch = html.match(/data-mb="([^"]+)"/);
    const mb = mbMatch ? mbMatch[1] : null;

    const countMatch = html.match(/class="sec-count"[^>]*>(\d+)</) || html.match(/Loading in (\d+) seconds/i);
    const rawWaitSeconds = countMatch ? parseInt(countMatch[1]) : 70;
    const waitSeconds = fastMode ? Math.min(rawWaitSeconds, 3) : Math.min(rawWaitSeconds, 10);

    logs.push(`[Pubg Engine] 2. ページ内認証スクリプト検出: data-p="${p}", data-mb="${mb}", nonce="${nonce ? nonce.substring(0, 6) + '...' : 'none'}"`);
    logs.push(`[Pubg Engine] 3. サーバー側要求待機タイマー: ${rawWaitSeconds}秒 (実行設定: ${waitSeconds}秒)`);

    let directUrl: string | null = null;
    let actualSizeBytes = 0;
    let actualSizeMb = mb ? `${parseFloat(mb).toFixed(2)} MB` : "44.00 MB";

    // Step 3: Perform directDownload AJAX handshake if parameters exist
    if (p && nonce) {
      logs.push(`[Pubg Engine] 4. 特殊認証POST送信 (z_do_ajax -> directDownload)...`);
      const postRes = await axios.post(ajaxUrl, new URLSearchParams({
        action: "z_do_ajax",
        _action: "directDownload",
        p: p,
        mb: mb || "50",
        nonce: nonce
      }).toString(), {
        headers: {
          ...DEFAULT_HEADERS,
          Referer: url,
          Origin: new URL(url).origin,
          "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
          "X-Requested-With": "XMLHttpRequest",
          "Cookie": cookies
        },
        timeout: 15000
      });

      const responseData = postRes.data;
      if (responseData && responseData.mes && typeof responseData.mes === "string" && responseData.mes.startsWith("http")) {
        directUrl = responseData.mes;
        logs.push(`[Pubg Engine] 5. 直リンク発行成功: ${directUrl.substring(0, 45)}...`);

        // Check real Content-Length via HEAD request
        try {
          const headRes = await axios.head(encodeURI(directUrl), {
            headers: {
              ...DEFAULT_HEADERS,
              Referer: url
            },
            timeout: 10000
          });
          const cl = headRes.headers["content-length"];
          if (cl) {
            actualSizeBytes = parseInt(String(cl), 10);
            actualSizeMb = `${(actualSizeBytes / 1024 / 1024).toFixed(2)} MB`;
            logs.push(`[Pubg Engine] 6. 実ファイルサイズ検証完了: ${actualSizeBytes.toLocaleString()} bytes (${actualSizeMb})`);
          }
        } catch (headErr: any) {
          logs.push(`[Pubg Engine] (HEAD確認スキップ: ${headErr.message})`);
        }
      } else {
        logs.push(`[Pubg Engine] 応答メッセージ: ${JSON.stringify(responseData)}`);
      }
    }

    const proxyStreamUrl = `/api/download/file?directUrl=${encodeURIComponent(directUrl || url)}&filename=${encodeURIComponent(fileName || "download.rar")}`;

    return res.json({
      success: true,
      fileName,
      sourceUrl: url,
      directUrl: directUrl || url,
      proxyStreamUrl,
      actualSizeBytes,
      actualSizeMb,
      p,
      mb,
      nonce,
      waitSeconds,
      rawWaitSeconds,
      requiresAuth: true,
      logs
    });
  } catch (err: any) {
    logs.push(`[Pubg Engine Error] ${err.message}`);
    return res.status(500).json({
      success: false,
      error: err.message,
      logs
    });
  }
});

// Ensure cache directory exists for server-side buffered downloads
const DL_CACHE_DIR = path.join("/tmp", "dl_cache");
try {
  if (!fs.existsSync(DL_CACHE_DIR)) {
    fs.mkdirSync(DL_CACHE_DIR, { recursive: true });
  }
} catch (e) {
  console.error("Failed to create DL_CACHE_DIR", e);
}

interface ServerDownloadJob {
  jobId: string;
  sourceUrl: string;
  directUrl: string;
  fileName: string;
  filePath: string;
  status: "resolving" | "downloading" | "completed" | "failed";
  downloadedBytes: number;
  totalBytes: number;
  speedMb: string;
  percent: number;
  elapsedSeconds: number;
  timeoutSeconds: number;
  error?: string;
  startedAt: number;
  lastActivityAt: number;
  isStalled: boolean;
  logs: string[];
}

const serverDownloadJobs = new Map<string, ServerDownloadJob>();

// Helper to resolve direct download URL from landing page
async function resolveLeechtopDirectUrl(url: string, isFast: boolean, signal: AbortSignal, logs: string[]): Promise<string> {
  logs.push(`[Server DL] 1. ランディングページ解析中...`);
  const landingRes = await axios.get(url, {
    headers: { ...DEFAULT_HEADERS, Referer: "https://dl-raw.si/" },
    timeout: isFast ? 15000 : 25000,
    httpAgent: keepAliveHttpAgent,
    httpsAgent: keepAliveHttpsAgent,
    signal
  });

  const html = landingRes.data;
  const cookies = (landingRes.headers["set-cookie"] || []).map((c: string) => c.split(";")[0]).join("; ");
  const nonceMatch = html.match(/"nonce":"([^"]+)"/);
  const nonce = nonceMatch ? nonceMatch[1] : null;
  const ajaxUrlMatch = html.match(/"ajax_url":"([^"]+)"/);
  const ajaxUrl = ajaxUrlMatch ? ajaxUrlMatch[1].replace(/\\\//g, "/") : "https://leechtop.com/wp-admin/admin-ajax.php";
  const pMatch = html.match(/data-p="([^"]+)"/);
  const p = pMatch ? pMatch[1] : null;
  const mbMatch = html.match(/data-mb="([^"]+)"/);
  const mb = mbMatch ? mbMatch[1] : null;

  if (!p || !nonce) {
    throw new Error("認証トークン(data-p, nonce)の抽出に失敗しました");
  }

  logs.push(`[Server DL] 2. 特殊認証POST (z_do_ajax -> directDownload)...`);
  const postRes = await axios.post(
    ajaxUrl,
    new URLSearchParams({
      action: "z_do_ajax",
      _action: "directDownload",
      p: p,
      mb: mb || "50",
      nonce: nonce
    }).toString(),
    {
      headers: {
        ...DEFAULT_HEADERS,
        Referer: url,
        Origin: new URL(url).origin,
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "X-Requested-With": "XMLHttpRequest",
        Cookie: cookies
      },
      timeout: isFast ? 15000 : 25000,
      httpAgent: keepAliveHttpAgent,
      httpsAgent: keepAliveHttpsAgent,
      signal
    }
  );

  if (postRes.data && postRes.data.mes && typeof postRes.data.mes === "string" && postRes.data.mes.startsWith("http")) {
    return postRes.data.mes;
  }
  throw new Error("直リンクの発行に失敗しました: " + (postRes.data?.mes || "応答なし"));
}

// 4.1 Server-Side Background Fetch: Start Job (Resilient Persistent Engine)
app.post("/api/download/server-fetch/start", async (req, res) => {
  const { url, fileName, fastMode } = req.body;
  if (!url) {
    return res.status(400).json({ success: false, error: "url is required" });
  }

  const isFast = fastMode === true || fastMode === "true";
  const timeoutSeconds = isFast ? 60 : 180; // 高速1分 (60s), 標準3分 (180s)
  const timeoutMs = timeoutSeconds * 1000;

  const safeFileName = (fileName || "archive.rar").replace(/[\/\\?%*:|"<>]/g, "_");
  const jobId = Date.now().toString(36) + Math.random().toString(36).substring(2, 7);
  const tempFilePath = path.join(DL_CACHE_DIR, `${jobId}_${safeFileName}`);

  // Delete existing file if any
  try {
    if (fs.existsSync(tempFilePath)) {
      fs.unlinkSync(tempFilePath);
    }
  } catch {}

  const job: ServerDownloadJob = {
    jobId,
    sourceUrl: url,
    directUrl: "",
    fileName: safeFileName,
    filePath: tempFilePath,
    status: "resolving",
    downloadedBytes: 0,
    totalBytes: 0,
    speedMb: "0.00",
    percent: 0,
    elapsedSeconds: 0,
    timeoutSeconds,
    startedAt: Date.now(),
    lastActivityAt: Date.now(),
    isStalled: false,
    logs: [`[Server DL] ジョブ開始: ${safeFileName} (タイムアウト上限: ${isFast ? '高速1分 (60s)' : '標準3分 (180s)'})`]
  };

  serverDownloadJobs.set(jobId, job);

  // Background execution with timeout watchdog and persistent Range resuming
  (async () => {
    const startTime = Date.now();
    const deadline = startTime + timeoutMs;
    const streamAbortController = new AbortController();
    let currentStream: any = null;
    let currentWriteStream: any = null;

    const timeoutWatchdog = setTimeout(() => {
      if (job.status === "resolving" || job.status === "downloading") {
        job.status = "failed";
        job.error = `転送がタイムアウトしました (${isFast ? '高速1分' : '標準3分'}の上限 ${timeoutSeconds}秒を超過)`;
        job.logs.push(`[Server DL Timeout] ⏱️ ${job.error}`);
        console.warn(`[Server DL Timeout] Job ${jobId} reached timeout of ${timeoutSeconds}s`);

        try {
          streamAbortController.abort();
        } catch {}
        try {
          if (currentStream && typeof currentStream.destroy === "function") {
            currentStream.destroy();
          }
        } catch {}
        try {
          if (currentWriteStream && typeof currentWriteStream.destroy === "function") {
            currentWriteStream.destroy();
          }
        } catch {}
        try {
          if (fs.existsSync(tempFilePath)) {
            fs.unlinkSync(tempFilePath);
          }
        } catch {}
      }
    }, timeoutMs);

    try {
      while (Date.now() < deadline && (job.status as string) !== "failed" && (job.status as string) !== "completed") {
        // Step 1: Resolve Direct URL if not available
        if (!job.directUrl) {
          try {
            job.directUrl = await resolveLeechtopDirectUrl(url, isFast, streamAbortController.signal, job.logs);
            job.status = "downloading";
            job.logs.push(`[Server DL] 3. 直リンク取得成功。データ転送を開始中 (セッション維持)...`);
          } catch (resErr: any) {
            if (Date.now() >= deadline) break;
            job.logs.push(`[Server DL Retry] 認証再試行中 (${resErr.message})。2秒後に再試行します...`);
            await new Promise((r) => setTimeout(r, 2000));
            continue;
          }
        }

        if (Date.now() >= deadline || (job.status as string) === "failed") break;

        // Step 2: Stream Download with TCP KeepAlive (Fresh token stream)
        const requestHeaders: Record<string, string> = {
          ...DEFAULT_HEADERS,
          Referer: "https://leechtop.com/",
          Accept: "*/*",
          "Accept-Encoding": "identity"
        };

        let cleanDirectUrl = job.directUrl;
        try {
          cleanDirectUrl = encodeURI(decodeURI(job.directUrl));
        } catch {
          cleanDirectUrl = encodeURI(job.directUrl);
        }

        // Clean temp file before fresh stream attempt
        try {
          if (fs.existsSync(tempFilePath)) {
            fs.unlinkSync(tempFilePath);
          }
        } catch {}
        job.downloadedBytes = 0;

        try {
          const streamRes = await axios.get(cleanDirectUrl, {
            responseType: "stream",
            headers: requestHeaders,
            timeout: 0, // Managed by timeout watchdog
            maxContentLength: -1,
            maxBodyLength: -1,
            httpAgent: keepAliveHttpAgent,
            httpsAgent: keepAliveHttpsAgent,
            signal: streamAbortController.signal
          });

          currentStream = streamRes.data;

          const cl = streamRes.headers["content-length"];
          if (cl) {
            job.totalBytes = parseInt(String(cl), 10);
          }

          const fileWriteStream = fs.createWriteStream(tempFilePath);
          currentWriteStream = fileWriteStream;

          await new Promise<void>((resolve) => {
            let lastBytes = 0;
            let lastSpeedCheck = Date.now();

            streamRes.data.on("data", (chunk: Buffer) => {
              if ((job.status as string) === "failed") return;
              job.downloadedBytes += chunk.length;
              job.lastActivityAt = Date.now();
              job.isStalled = false;

              const now = Date.now();
              if (now - lastSpeedCheck >= 1000) {
                const sec = Math.max((now - lastSpeedCheck) / 1000, 0.1);
                const diff = job.downloadedBytes - lastBytes;
                job.speedMb = (diff / 1024 / 1024 / sec).toFixed(2);
                job.elapsedSeconds = Math.round((now - job.startedAt) / 1000);
                if (job.totalBytes > 0) {
                  job.percent = Math.min(Math.round((job.downloadedBytes / job.totalBytes) * 100), 99);
                }
                lastBytes = job.downloadedBytes;
                lastSpeedCheck = now;
              }
            });

            streamRes.data.pipe(fileWriteStream);

            fileWriteStream.on("finish", () => {
              // Verify whether download finished completely (allow >= 99.9% tolerance for compression/header padding variations)
              const isNearComplete = job.totalBytes > 0 && job.downloadedBytes >= Math.floor(job.totalBytes * 0.998);
              if (job.totalBytes > 0 && job.downloadedBytes < job.totalBytes && !isNearComplete) {
                job.logs.push(`[Server DL Info] 相手先が途中で切断 (${(job.downloadedBytes / 1024 / 1024).toFixed(2)} / ${(job.totalBytes / 1024 / 1024).toFixed(2)} MB)。最新トークンで再接続します...`);
                job.directUrl = ""; // Force fresh token
                resolve();
              } else if (job.downloadedBytes > 0) {
                job.status = "completed";
                job.percent = 100;
                job.speedMb = "0.00";
                job.elapsedSeconds = Math.round((Date.now() - job.startedAt) / 1000);
                job.logs.push(`[Server DL] 4. ✅ サーバー側ダウンロード完了: ${job.downloadedBytes.toLocaleString()} bytes (${job.elapsedSeconds}s)`);
                resolve();
              } else {
                job.directUrl = "";
                resolve();
              }
            });

            streamRes.data.on("error", (err: any) => {
              job.logs.push(`[Server DL Stream] 通信エラー (${err.message})。最新トークンを取得して再接続します...`);
              job.directUrl = "";
              resolve();
            });

            fileWriteStream.on("error", (err: any) => {
              job.logs.push(`[Server DL Write Error] ${err.message}`);
              job.directUrl = "";
              resolve();
            });
          });

          if ((job.status as string) === "completed") {
            clearTimeout(timeoutWatchdog);
            break;
          }
        } catch (streamErr: any) {
          if (Date.now() >= deadline || (job.status as string) === "failed") break;

          job.logs.push(`[Server DL KeepAlive] 相手先待機中・再試行 (${streamErr.message})...`);
          job.directUrl = ""; // Always refresh token on stream error
          await new Promise((r) => setTimeout(r, 1500));
        }
      }
    } catch (globalErr: any) {
      if (job.status !== "completed" && job.status !== "failed") {
        job.status = "failed";
        job.error = globalErr.message;
        job.logs.push(`[Server DL Fatal] ${globalErr.message}`);
      }
    } finally {
      clearTimeout(timeoutWatchdog);
    }
  })();

  return res.json({
    success: true,
    jobId,
    fileName: safeFileName,
    timeoutSeconds
  });
});

// 4.2 Server-Side Background Fetch: Status Polling
app.get("/api/download/server-fetch/status", (req, res) => {
  const jobId = req.query.jobId as string;
  if (!jobId || !serverDownloadJobs.has(jobId)) {
    return res.status(404).json({ success: false, error: "Job not found" });
  }

  const job = serverDownloadJobs.get(jobId)!;
  const now = Date.now();
  const idleSec = (now - job.lastActivityAt) / 1000;

  // Stalled detection (0 B/s on source server)
  if (job.status === "downloading" && idleSec > 2.5) {
    job.isStalled = true;
    job.speedMb = "0.00";
  }

  return res.json({
    success: true,
    jobId: job.jobId,
    status: job.status,
    fileName: job.fileName,
    downloadedBytes: job.downloadedBytes,
    totalBytes: job.totalBytes,
    downloadedMb: (job.downloadedBytes / 1024 / 1024).toFixed(2),
    totalMb: job.totalBytes > 0 ? (job.totalBytes / 1024 / 1024).toFixed(2) : "Unknown",
    percent: job.percent,
    speedMb: job.speedMb,
    elapsedSeconds: Math.round((now - job.startedAt) / 1000),
    isStalled: job.isStalled,
    error: job.error,
    cachedDownloadUrl: job.status === "completed" ? `/api/download/cached-file?jobId=${job.jobId}` : undefined,
    logs: job.logs
  });
});

// 4.2.5 Fast 1ms cache check endpoint to verify file readiness before downloading
app.get("/api/download/check-cache", (req, res) => {
  const jobId = (req.query.jobId as string) || "";
  let requestedFileName = (req.query.filename as string) || "";
  try {
    requestedFileName = decodeURIComponent(requestedFileName);
  } catch {}

  let found = false;
  let fileSize = 0;
  let matchedFileName = requestedFileName;

  if (jobId && serverDownloadJobs.has(jobId)) {
    const job = serverDownloadJobs.get(jobId)!;
    if (job.status === "completed" && job.filePath && fs.existsSync(job.filePath)) {
      try {
        fileSize = fs.statSync(job.filePath).size;
        if (fileSize > 0) {
          found = true;
          matchedFileName = job.fileName || requestedFileName;
        }
      } catch {}
    }
  }

  if (!found && fs.existsSync(DL_CACHE_DIR)) {
    try {
      const files = fs.readdirSync(DL_CACHE_DIR);
      if (jobId) {
        const match = files.find((f) => f.startsWith(`${jobId}_`) || f.includes(jobId));
        if (match) {
          try {
            const s = fs.statSync(path.join(DL_CACHE_DIR, match));
            if (s.size > 0) {
              found = true;
              fileSize = s.size;
              matchedFileName = match.replace(`${jobId}_`, "") || requestedFileName;
            }
          } catch {}
        }
      }

      if (!found && requestedFileName) {
        const norm = (s: string) => (s || "").toLowerCase().replace(/\.(rar|zip)$/i, "").replace(/[\s_\-–—]+/g, "");
        const reqNorm = norm(requestedFileName);
        for (const f of files) {
          try {
            const clean = f.replace(/^[a-z0-9]{10,25}_/, "");
            const fNorm = norm(clean);
            if (fNorm === reqNorm || fNorm.includes(reqNorm) || reqNorm.includes(fNorm)) {
              const s = fs.statSync(path.join(DL_CACHE_DIR, f));
              if (s.size > 0) {
                found = true;
                fileSize = s.size;
                matchedFileName = clean;
                break;
              }
            }
          } catch {}
        }
      }
    } catch {}
  }

  return res.json({
    exists: found,
    size: fileSize,
    fileName: matchedFileName,
    downloadUrl: `/api/download/cached-file?jobId=${encodeURIComponent(jobId)}&filename=${encodeURIComponent(matchedFileName)}`
  });
});

// 4.3 Serve the completely downloaded file from local server disk (Super high speed, Range support & resilient fallback)
app.get("/api/download/cached-file", async (req, res) => {
  const jobId = (req.query.jobId as string) || "";
  let requestedFileName = (req.query.filename as string) || "";
  try {
    requestedFileName = decodeURIComponent(requestedFileName);
  } catch {}
  const sourceUrl = (req.query.sourceUrl as string) || (req.query.url as string) || "";
  const directUrlParam = (req.query.directUrl as string) || "";

  console.log(`[Cached File Request] jobId=${jobId}, fileName="${requestedFileName}", sourceUrl=${sourceUrl.slice(0, 50)}...`);

  try {
    let filePath: string | null = null;
    let fileName: string = requestedFileName || "download.rar";

    // Helper: Normalize string for comparison (removes extension, underscores, spaces, dashes)
    const normalizeName = (s: string) =>
      (s || "")
        .toLowerCase()
        .replace(/\.(rar|zip)$/i, "")
        .replace(/[\s_\-–—]+/g, "")
        .replace(/[\/\\?%*:|"<>]/g, "");

    // 1. Check in-memory active jobs
    if (jobId && serverDownloadJobs.has(jobId)) {
      const job = serverDownloadJobs.get(jobId)!;
      if (job.filePath && fs.existsSync(job.filePath)) {
        try {
          if (fs.statSync(job.filePath).size > 0) {
            filePath = job.filePath;
            fileName = job.fileName || fileName;
            console.log(`[Cached File Match] Memory job hit: ${job.filePath}`);
          }
        } catch {}
      }
    }

    // 2. Multi-tier search in DL_CACHE_DIR on disk
    if (!filePath && fs.existsSync(DL_CACHE_DIR)) {
      let allFiles: string[] = [];
      try {
        allFiles = fs.readdirSync(DL_CACHE_DIR).filter((f) => {
          try {
            const fp = path.join(DL_CACHE_DIR, f);
            return fs.statSync(fp).size > 0;
          } catch {
            return false;
          }
        });
      } catch {}

      // Tier A: Match by jobId
      if (jobId && allFiles.length > 0) {
        const matchingByJobId = allFiles.filter((f) => f.startsWith(`${jobId}_`) || f.includes(jobId));
        if (matchingByJobId.length > 0) {
          const selected = matchingByJobId[0];
          filePath = path.join(DL_CACHE_DIR, selected);
          const rawName = selected.replace(`${jobId}_`, "");
          if (rawName) fileName = rawName;
          console.log(`[Cached File Match] Tier A (jobId) hit: ${selected}`);
        }
      }

      // Tier B: Exact normalized match (handles spaces vs underscores, e.g. 時間停止勇者_v22.rar vs 時間停止勇者 v22.rar)
      if (!filePath && requestedFileName && allFiles.length > 0) {
        const reqNorm = normalizeName(requestedFileName);
        const candidates = allFiles
          .map((f) => {
            try {
              const cleanName = f.replace(/^[a-z0-9]{10,25}_/, "");
              return {
                fileNameOnDisk: f,
                cleanName,
                norm: normalizeName(cleanName),
                mtime: fs.statSync(path.join(DL_CACHE_DIR, f)).mtimeMs
              };
            } catch {
              return null;
            }
          })
          .filter((c): c is { fileNameOnDisk: string; cleanName: string; norm: string; mtime: number } => c !== null)
          .sort((a, b) => b.mtime - a.mtime); // pick freshest file first

        const exactMatch = candidates.find((c) => c.norm === reqNorm);
        if (exactMatch) {
          filePath = path.join(DL_CACHE_DIR, exactMatch.fileNameOnDisk);
          fileName = exactMatch.cleanName || requestedFileName;
          console.log(`[Cached File Match] Tier B (normalized exact) hit: ${exactMatch.fileNameOnDisk}`);
        }

        // Tier C: Normalized substring match
        if (!filePath) {
          const subMatch = candidates.find((c) => c.norm.includes(reqNorm) || reqNorm.includes(c.norm));
          if (subMatch) {
            filePath = path.join(DL_CACHE_DIR, subMatch.fileNameOnDisk);
            fileName = subMatch.cleanName || requestedFileName;
            console.log(`[Cached File Match] Tier C (normalized substring) hit: ${subMatch.fileNameOnDisk}`);
          }
        }

        // Tier D: Match by volume/chapter number (e.g. v22, 22, ch03)
        if (!filePath) {
          const volMatch = requestedFileName.match(/(?:v|vol(?:ume)?\.?|第|ch(?:apter)?)\s*(\d+)/i);
          if (volMatch) {
            const volNum = volMatch[1];
            const volNumInt = parseInt(volNum, 10);
            const numPattern = new RegExp(`(?:v|vol|第|ch)?_?\\s*0*${volNumInt}(?:\\b|[^0-9]|$)`, "i");
            const volCandidate = candidates.find((c) => numPattern.test(c.fileNameOnDisk));
            if (volCandidate) {
              filePath = path.join(DL_CACHE_DIR, volCandidate.fileNameOnDisk);
              fileName = volCandidate.cleanName || requestedFileName;
              console.log(`[Cached File Match] Tier D (volume number ${volNum}) hit: ${volCandidate.fileNameOnDisk}`);
            }
          }
        }
      }
    }

    // Clean filename for HTTP Content-Disposition headers (RFC 6266 / RFC 5987)
    const cleanFileName = fileName.replace(/[\r\n"\\;]/g, "_").trim() || "download.rar";
    const asciiFallback = cleanFileName.replace(/[^\x20-\x7E]/g, "_").replace(/["\\;]/g, "_") || "download.rar";
    const utf8Encoded = encodeURIComponent(cleanFileName);

    // 3. If file exists on server disk, stream with HTTP Range support
    if (filePath && fs.existsSync(filePath)) {
      let fileSize = 0;
      try {
        fileSize = fs.statSync(filePath).size;
      } catch {}

      if (fileSize > 0) {
        const range = req.headers.range;

        res.setHeader("Accept-Ranges", "bytes");
        res.setHeader("Content-Disposition", `attachment; filename="${asciiFallback}"; filename*=UTF-8''${utf8Encoded}`);
        res.setHeader("Content-Type", "application/octet-stream");
        res.setHeader("Cache-Control", "public, max-age=3600");

        if (range) {
          const parts = range.replace(/bytes=/, "").split("-");
          const start = parseInt(parts[0], 10);
          const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;

          if (start >= fileSize || end >= fileSize) {
            res.status(416).setHeader("Content-Range", `bytes */${fileSize}`);
            return res.end();
          }

          const chunksize = end - start + 1;
          const fileStream = fs.createReadStream(filePath, { start, end });
          res.status(206);
          res.setHeader("Content-Range", `bytes ${start}-${end}/${fileSize}`);
          res.setHeader("Content-Length", String(chunksize));

          fileStream.on("error", (err) => {
            console.warn("[ReadStream Error (Range)]", err.message);
            if (!res.headersSent) res.status(404).end();
          });
          res.on("close", () => {
            fileStream.destroy();
          });
          return fileStream.pipe(res);
        } else {
          res.setHeader("Content-Length", String(fileSize));
          const fileStream = fs.createReadStream(filePath);
          fileStream.on("error", (err) => {
            console.warn("[ReadStream Error]", err.message);
            if (!res.headersSent) res.status(404).end();
          });
          res.on("close", () => {
            fileStream.destroy();
          });
          return fileStream.pipe(res);
        }
      }
    }

    // 4. On-demand streaming fallback if cache was cleared but sourceUrl/directUrl is available
    console.warn(`[Cached File Fallback] File not found on disk for "${requestedFileName}". Attempting live stream fallback.`);
    let streamTargetUrl = directUrlParam;
    if (!streamTargetUrl && sourceUrl) {
      try {
        const logs: string[] = [];
        const abortCtrl = new AbortController();
        streamTargetUrl = await resolveLeechtopDirectUrl(sourceUrl, true, abortCtrl.signal, logs);
      } catch (resolveErr: any) {
        console.warn("[Cached File Fallback] Resolve failed:", resolveErr.message);
      }
    }

    if (streamTargetUrl && streamTargetUrl.startsWith("http") && !streamTargetUrl.includes("dl-raw.si")) {
      console.log(`[Cached File Fallback] Streaming directly from upstream for: ${fileName}`);
      try {
        const proxyRes = await axios.get(streamTargetUrl, {
          responseType: "stream",
          headers: {
            ...DEFAULT_HEADERS,
            Referer: "https://leechtop.com/",
            Accept: "*/*"
          },
          timeout: 60000,
          maxContentLength: -1,
          maxBodyLength: -1,
          validateStatus: (status) => status >= 200 && status < 300
        });

        const cl = proxyRes.headers["content-length"];
        res.setHeader("Content-Disposition", `attachment; filename="${asciiFallback}"; filename*=UTF-8''${utf8Encoded}`);
        res.setHeader("Content-Type", "application/octet-stream");
        if (cl) res.setHeader("Content-Length", String(cl));
        res.setHeader("Cache-Control", "no-cache");

        proxyRes.data.on("error", (streamErr: any) => {
          console.warn("[Upstream Stream Error]", streamErr.message);
          if (!res.headersSent) res.status(404).end();
        });
        res.on("close", () => {
          if (proxyRes.data && typeof proxyRes.data.destroy === "function") {
            proxyRes.data.destroy();
          }
        });
        return proxyRes.data.pipe(res);
      } catch (proxyErr: any) {
        console.error("[Cached File Fallback Stream Error]", proxyErr.message);
      }
    }

    // 5. Clean, user-friendly 404 response with headers indicating cache expired (Never return 500)
    res.setHeader("X-Cache-Expired", "true");
    return res.status(404).json({
      success: false,
      error: "サーバーキャッシュ期限切れ (再試行ボタンを押してください)",
      fileName: requestedFileName,
      needRefetch: true
    });
  } catch (err: any) {
    console.error("[Cached File Handler Error]", err);
    if (!res.headersSent) {
      res.status(404).json({
        success: false,
        error: "キャッシュファイルの読み込みに失敗しました (再取得ボタンを押してください)",
        fileName: requestedFileName,
        needRefetch: true
      });
    }
  }
});

// 4.3.5 Bundle multiple completed files into a single ZIP archive for 1-click PC download
app.get("/api/download/bundle-zip", async (req, res) => {
  const jobIdsParam = (req.query.jobIds as string) || "";
  const rawTitle = (req.query.title as string) || "DL-RAW_Files";
  const safeTitle = cleanMangaTitle(rawTitle).trim() || "Manga";
  const jobIds = jobIdsParam.split(",").map((s) => s.trim()).filter(Boolean);

  console.log(`[Bundle Zip Request] title="${safeTitle}", jobIds=${jobIds.join(",")}`);

  // Find all cached files corresponding to the jobIds
  const filesToAdd: { filePath: string; name: string }[] = [];

  for (const jId of jobIds) {
    if (serverDownloadJobs.has(jId)) {
      const job = serverDownloadJobs.get(jId)!;
      if (job.filePath && fs.existsSync(job.filePath)) {
        filesToAdd.push({ filePath: job.filePath, name: job.fileName });
        continue;
      }
    }
    // Check disk in DL_CACHE_DIR
    if (fs.existsSync(DL_CACHE_DIR)) {
      const allFiles = fs.readdirSync(DL_CACHE_DIR);
      const matched = allFiles.find((f) => f.startsWith(`${jId}_`));
      if (matched) {
        const fp = path.join(DL_CACHE_DIR, matched);
        const name = matched.replace(`${jId}_`, "");
        filesToAdd.push({ filePath: fp, name });
      }
    }
  }

  // If no specific jobIds matched or jobIds was empty, find all files with matching title in DL_CACHE_DIR
  if (filesToAdd.length === 0 && fs.existsSync(DL_CACHE_DIR)) {
    const allFiles = fs.readdirSync(DL_CACHE_DIR);
    for (const f of allFiles) {
      const fp = path.join(DL_CACHE_DIR, f);
      try {
        if (fs.statSync(fp).size > 0) {
          const cleanName = f.replace(/^[a-z0-9]{10,25}_/, "");
          filesToAdd.push({ filePath: fp, name: cleanName });
        }
      } catch {}
    }
  }

  if (filesToAdd.length === 0) {
    return res.status(404).json({ success: false, error: "ダウンロード対象のファイルが見つかりません。まず各巻の取得を実行してください。" });
  }

  const zipFileName = `${safeTitle}_全巻一括.zip`;
  const asciiFallback = zipFileName.replace(/[^\x20-\x7E]/g, "_") || "all_volumes.zip";
  try {
    const utf8Encoded = encodeURIComponent(zipFileName);

    res.setHeader("Content-Disposition", `attachment; filename="${asciiFallback}"; filename*=UTF-8''${utf8Encoded}`);
    res.setHeader("Content-Type", "application/zip");
    res.setHeader("Cache-Control", "no-cache");

    const zip = new JSZip();
    for (const item of filesToAdd) {
      zip.file(`${safeTitle}/${item.name}`, fs.createReadStream(item.filePath));
    }

    zip.generateNodeStream({ type: "nodebuffer", streamFiles: true, compression: "STORE" })
      .on("error", (err: any) => {
        console.error("[Bundle Zip Stream Error]", err);
        if (!res.headersSent) res.status(500).end();
      })
      .pipe(res)
      .on("finish", () => {
        console.log(`[Bundle Zip Complete] Streamed ${filesToAdd.length} files in ${zipFileName}`);
      });
  } catch (zipErr: any) {
    console.error("[Bundle Zip Handler Error]", zipErr);
    if (!res.headersSent) {
      res.status(500).json({ success: false, error: `ZIPバンドル生成エラー: ${zipErr.message}` });
    }
  }
});

// 4.4 Clean up cached file from server disk (delayed cleanup or explicit manual cleanup)
app.post("/api/download/clear-cache", (req, res) => {
  const { jobId } = req.body;
  if (!jobId) {
    return res.status(400).json({ success: false, error: "jobId is required" });
  }

  // Keep the cache for at least 30 minutes to allow repeated user downloads
  setTimeout(() => {
    try {
      const job = serverDownloadJobs.get(jobId);
      if (job && job.filePath && fs.existsSync(job.filePath)) {
        fs.unlinkSync(job.filePath);
        console.log(`[Cache Cleared] Deleted temporary file: ${job.filePath}`);
      }
      serverDownloadJobs.delete(jobId);
    } catch (e) {
      console.error("Error deleting cached file:", e);
    }
  }, 30 * 60 * 1000);

  return res.json({ success: true, message: "Cache scheduled for retention and cleanup" });
});

// 4.5 Image and Cover Thumbnail Proxy (Prevents 403 hotlink blocks and 500 errors)
app.get("/api/image-proxy", async (req, res) => {
  const imageUrl = req.query.url as string;
  if (!imageUrl) {
    return res.status(400).send("url parameter is required");
  }

  try {
    const imgRes = await axios.get(imageUrl, {
      responseType: "arraybuffer",
      headers: {
        ...DEFAULT_HEADERS,
        Referer: "https://dl-raw.si/",
        Accept: "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8"
      },
      timeout: 12000
    });

    const contentType = imgRes.headers["content-type"] || "image/jpeg";
    res.setHeader("Content-Type", String(contentType));
    res.setHeader("Cache-Control", "public, max-age=86400");
    return res.send(Buffer.from(imgRes.data));
  } catch (err: any) {
    console.warn(`[Image Proxy Warning] Failed to proxy image ${imageUrl}: ${err.message}`);
    // Return a clean 1x1 transparent PNG fallback rather than 500
    res.setHeader("Content-Type", "image/png");
    res.setHeader("Cache-Control", "public, max-age=3600");
    const transparentPng = Buffer.from(
      "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=",
      "base64"
    );
    return res.send(transparentPng);
  }
});

// 5. Real File Download & Streaming Proxy Endpoint
app.get("/api/download/file", async (req, res) => {
  const rawDirectUrl = req.query.directUrl as string;
  const fileName = (req.query.filename as string) || "archive.rar";

  if (!rawDirectUrl || rawDirectUrl === "undefined") {
    return res.status(400).send("directUrl query parameter is required");
  }

  let directUrl = rawDirectUrl;
  try {
    // If passed a landing page URL instead of direct file, resolve it first
    if (directUrl.includes("leechtop.com") && !directUrl.includes("/wp-content/") && !directUrl.includes(".rar") && !directUrl.includes(".zip")) {
      const logs: string[] = [];
      const abortCtrl = new AbortController();
      const resolved = await resolveLeechtopDirectUrl(directUrl, true, abortCtrl.signal, logs);
      if (resolved && resolved.startsWith("http")) {
        directUrl = resolved;
      }
    }
  } catch (resolveErr: any) {
    console.warn("[Download Proxy] Auto-resolve note:", resolveErr.message);
  }

  // Properly normalize and encode URI
  try {
    directUrl = encodeURI(decodeURI(directUrl));
  } catch {
    directUrl = encodeURI(directUrl);
  }

  console.log(`[Proxy Stream] Starting download proxy for: ${fileName} (${directUrl.substring(0, 70)}...)`);

  try {
    const streamRes = await axios.get(directUrl, {
      responseType: "stream",
      headers: {
        ...DEFAULT_HEADERS,
        Referer: "https://leechtop.com/",
        Accept: "*/*",
        "Accept-Encoding": "identity"
      },
      timeout: 0, // unlimited timeout
      maxContentLength: -1,
      maxBodyLength: -1
    });

    const contentLength = streamRes.headers["content-length"];
    const contentType = streamRes.headers["content-type"] || "application/octet-stream";

    res.setHeader("Content-Disposition", `attachment; filename="${encodeURIComponent(fileName)}"; filename*=UTF-8''${encodeURIComponent(fileName)}`);
    res.setHeader("Content-Type", String(contentType));
    res.setHeader("Cache-Control", "no-cache, no-transform, no-store");
    res.setHeader("X-Accel-Buffering", "no");
    res.setHeader("Connection", "keep-alive");
    if (contentLength) {
      res.setHeader("Content-Length", String(contentLength));
    }

    if (typeof res.flushHeaders === "function") {
      res.flushHeaders();
    }

    req.socket.setKeepAlive(true, 10000);
    req.socket.setTimeout(0);

    streamRes.data.on("error", (streamErr: any) => {
      console.error("[Stream Error during pipe]", streamErr.message);
      if (!res.headersSent) {
        res.status(502).end();
      } else {
        res.end();
      }
    });

    streamRes.data.pipe(res);
  } catch (err: any) {
    console.error("[Stream Download Error]", err.message);
    if (!res.headersSent) {
      res.status(502).send(`Download streaming error: ${err.message}`);
    }
  }
});

// 6. Real-time Batch ZIP Archiving Endpoint (Saves to DL-RAW/<Title>/ structure)
app.post("/api/download/zip-batch", async (req, res) => {
  const { cleanTitle, items } = req.body;
  const title = cleanMangaTitle(cleanTitle || "DL-RAW_Download");
  const downloadItems = Array.isArray(items) ? items : [];

  if (downloadItems.length === 0) {
    return res.status(400).json({ error: "items array is required" });
  }

  const safeTitle = title.replace(/[\/\\:\*\?"<>\|]/g, "_").trim();
  const zipFileName = `DL-RAW_${safeTitle}.zip`;

  const zip = new JSZip();
  const folder = zip.folder(`DL-RAW/${safeTitle}`) || zip;

  // Process and add each file into DL-RAW/<Title>/<filename>
  for (let i = 0; i < downloadItems.length; i++) {
    const item = downloadItems[i];
    const fileName = item.fileName || `volume_${i + 1}.rar`;

    let directUrl = item.directUrl;

    // If directUrl is missing, try resolving from sourceUrl (pubg)
    if (!directUrl && item.sourceUrl) {
      try {
        const landingRes = await axios.get(item.sourceUrl, {
          headers: { ...DEFAULT_HEADERS, Referer: "https://dl-raw.si/" },
          timeout: 15000
        });
        const html = landingRes.data;
        const pMatch = html.match(/data-p=["']([^"']+)["']/i);
        const mbMatch = html.match(/data-mb=["']([^"']+)["']/i);
        const nonceMatch = html.match(/nonce=["']([^"']+)["']/i) || html.match(/name=["']nonce["']\s+value=["']([^"']+)["']/i);
        const cookies = (landingRes.headers["set-cookie"] || []).map((c: string) => c.split(";")[0]).join("; ");

        if (pMatch && nonceMatch) {
          const authRes = await axios.post(
            "https://leechtop.com/wp-admin/admin-ajax.php",
            new URLSearchParams({
              action: "z_do_ajax",
              _action: "directDownload",
              p: pMatch[1],
              mb: mbMatch ? mbMatch[1] : "",
              nonce: nonceMatch[1]
            }).toString(),
            {
              headers: {
                ...DEFAULT_HEADERS,
                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                Referer: item.sourceUrl,
                Origin: "https://leechtop.com",
                "X-Requested-With": "XMLHttpRequest",
                Cookie: cookies
              },
              timeout: 15000
            }
          );
          if (authRes.data && (authRes.data.mes || authRes.data.directDownload)) {
            directUrl = authRes.data.mes || authRes.data.directDownload;
          }
        }
      } catch (err: any) {
        console.warn(`[Batch Zip Warning] Failed resolving URL for ${fileName}:`, err.message);
      }
    }

    if (directUrl) {
      try {
        let cleanDirectUrl = directUrl;
        try {
          cleanDirectUrl = encodeURI(decodeURI(directUrl));
        } catch {
          cleanDirectUrl = encodeURI(directUrl);
        }
        const fileRes = await axios.get(cleanDirectUrl, {
          responseType: "arraybuffer",
          headers: {
            ...DEFAULT_HEADERS,
            Referer: "https://leechtop.com/",
            Accept: "*/*"
          },
          timeout: 120000,
          maxContentLength: Infinity,
          maxBodyLength: Infinity
        });
        folder.file(fileName, Buffer.from(fileRes.data));
      } catch (err: any) {
        console.error(`[Batch Zip Item Error] Failed downloading ${fileName}:`, err.message);
        folder.file(`ERROR_${fileName}.txt`, `Download failed for ${fileName}: ${err.message}`);
      }
    } else {
      folder.file(`FAILED_${fileName}.txt`, `No direct download link available for ${fileName}`);
    }
  }

  // Add README instruction file inside the DL-RAW/Title directory
  folder.file(
    "README.txt",
    `DL-RAW.SI 漫画一括ダウンロード\n作品名: ${title}\n保存パス: DL-RAW/${safeTitle}/\n取得件数: ${downloadItems.length} 件\nダウンロード完了日時: ${new Date().toLocaleString("ja-JP")}\n`
  );

  try {
    const zipBuffer = await zip.generateAsync({
      type: "nodebuffer",
      compression: "DEFLATE",
      compressionOptions: { level: 5 }
    });

    res.setHeader("Content-Type", "application/zip");
    res.setHeader("Content-Disposition", `attachment; filename="${encodeURIComponent(zipFileName)}"; filename*=UTF-8''${encodeURIComponent(zipFileName)}`);
    res.setHeader("Content-Length", zipBuffer.length.toString());
    res.send(zipBuffer);
  } catch (genErr: any) {
    console.error("[Batch Zip Generate Error]", genErr);
    if (!res.headersSent) {
      res.status(500).json({ error: genErr.message });
    }
  }
});

// 7. Generate Standalone Python / Automation Script
app.post("/api/generate-script", (req, res) => {
  const { title, cleanTitle, items } = req.body;
  const rawTitle = title || "時間停止勇者 raw 第01-22巻";
  const mangaTitle = cleanTitle || cleanMangaTitle(rawTitle);
  const safeMangaTitle = mangaTitle.replace(/[\/\?<>\\:\*\|":\s]/g, "_");
  const fileItems = Array.isArray(items) ? items : [];

  const script = `# -*- coding: utf-8 -*-
"""
DL-RAW.SI & Pubg File (Leechtop) 完全自動ダウンローダー
対象作品: ${mangaTitle}
生成日: ${new Date().toLocaleString("ja-JP")}

【保存先】
ブラウザの保存先/DL-RAW/${safeMangaTitle}/ 以下に自動保存されます。

【動作仕様】
1. Leechtop / Pubg File ページから認証トークン (nonce, data-p, data-mb) を抽出
2. 待機タイマー (WAIT) を自動カウントダウン
3. 特殊認証POST (directDownload) を送信して直リンクを取得
4. 実ファイル (数十MB〜数百MB) を破損なくストリーミング保存
"""

import os
import re
import time
import requests
from urllib.parse import quote, urlparse

# 保存先フォルダ設定 (DL-RAW/タイトル)
DOWNLOAD_DIR = os.path.join(os.path.expanduser("~"), "Downloads", "DL-RAW", "${safeMangaTitle}")
os.makedirs(DOWNLOAD_DIR, exist_ok=True)

# ダウンロード対象リスト
DOWNLOAD_LIST = [
${fileItems.map((it: any) => `    {"name": "${it.fileName}", "url": "${it.url}", "size": "${it.size || ''}"},`).join("\n")}
]

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Referer": "https://dl-raw.si/",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
}

def resolve_and_download(session, item, index, total):
    file_name = item["name"]
    page_url = item["url"]
    save_path = os.path.join(DOWNLOAD_DIR, file_name)

    if os.path.exists(save_path) and os.path.getsize(save_path) > 1024 * 1024:
        print(f"[{index}/{total}] スキップ (既に完全ダウンロード済み): {file_name} ({os.path.getsize(save_path)/1024/1024:.2f} MB)")
        return True

    print(f"\\n=======================================================")
    print(f"[{index}/{total}] 処理開始: {file_name} (予定サイズ: {item.get('size', '')})")
    print(f"ページURL: {page_url}")

    try:
        # Step 1: ランディングページアクセス & 認証要素抽出
        print(" -> [Step 1] ランディングページ解析中...")
        page_res = session.get(page_url, headers=HEADERS, timeout=15)
        html = page_res.text

        nonce_m = re.search(r'"nonce":"([^"]+)"', html)
        ajax_m = re.search(r'"ajax_url":"([^"]+)"', html)
        p_m = re.search(r'data-p="([^"]+)"', html)
        mb_m = re.search(r'data-mb="([^"]+)"', html)
        count_m = re.search(r'class="sec-count"[^>]*>(\\d+)<', html) or re.search(r'Loading in (\\d+) seconds', html)

        nonce = nonce_m.group(1) if nonce_m else None
        ajax_url = ajax_m.group(1).replace("\\\\/", "/") if ajax_m else "https://leechtop.com/wp-admin/admin-ajax.php"
        p = p_m.group(1) if p_m else None
        mb = mb_m.group(1) if mb_m else "50"
        wait_sec = int(count_m.group(1)) if count_m else 15

        print(f"    抽出データ: p={p}, mb={mb}, nonce={nonce[:6] if nonce else 'none'}...")

        # Step 2: 待機時間タイマー (WAIT)
        print(f" -> [Step 2] サーバー指定タイマー待機中 ({wait_sec} 秒)...")
        for remaining in range(wait_sec, 0, -1):
            print(f"    ⏳ 残り {remaining:2d} 秒...", end="\\r", flush=True)
            time.sleep(1)
        print(f"\\n -> [Step 3] 認証リクエスト送信中 (directDownload)...")

        # Step 3: 特殊認証POSTで直リンクを取得
        ajax_headers = {
            **HEADERS,
            "Referer": page_url,
            "Origin": f"{urlparse(page_url).scheme}://{urlparse(page_url).netloc}",
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "X-Requested-With": "XMLHttpRequest"
        }
        ajax_data = {
            "action": "z_do_ajax",
            "_action": "directDownload",
            "p": p,
            "mb": mb,
            "nonce": nonce
        }
        post_res = session.post(ajax_url, data=ajax_data, headers=ajax_headers, timeout=20)
        res_json = post_res.json()
        direct_url = res_json.get("mes")

        if not direct_url or not direct_url.startswith("http"):
            print(f" -> [Error] 直リンク取得失敗: {res_json}")
            return False

        print(f" -> [Step 4] ✅ 直リンク取得成功: {direct_url[:60]}...")

        # Step 4: 実ファイルストリーミングダウンロード (プログレス表示)
        dl_headers = {**HEADERS, "Referer": page_url}
        dl_res = session.get(direct_url, headers=dl_headers, stream=True, timeout=60)
        
        total_size = int(dl_res.headers.get("content-length", 0))
        total_mb = total_size / 1024 / 1024
        print(f" -> [Step 5] ダウンロード開始: 合計 {total_mb:.2f} MB")

        downloaded = 0
        start_time = time.time()

        with open(save_path, "wb") as f:
            for chunk in dl_res.iter_content(chunk_size=65536):
                if chunk:
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total_size > 0:
                        percent = (downloaded / total_size) * 100
                        mb_done = downloaded / 1024 / 1024
                        speed = mb_done / max(time.time() - start_time, 0.001)
                        print(f"    ⬇️ {mb_done:.2f}/{total_mb:.2f} MB ({percent:.1f}%) - {speed:.1f} MB/s", end="\\r", flush=True)

        final_mb = os.path.getsize(save_path) / 1024 / 1024
        print(f"\\n -> [Step 6] 🎉 保存完了! 実ファイルサイズ: {final_mb:.2f} MB -> {save_path}")
        return True

    except Exception as e:
        print(f"\\n -> [Error] ダウンロード処理失敗: {e}")
        return False

def main():
    print("=" * 60)
    print("  DL-RAW.SI 漫画自動シーケンシャルダウンローダー")
    print(f"  作品: {DOWNLOAD_LIST[0]['name'].split(' ')[0] if DOWNLOAD_LIST else ''}")
    print(f"  対象: {len(DOWNLOAD_LIST)} ファイル")
    print(f"  保存先: {DOWNLOAD_DIR}")
    print("=" * 60)

    session = requests.Session()
    success_count = 0

    for idx, item in enumerate(DOWNLOAD_LIST, 1):
        if resolve_and_download(session, item, idx, len(DOWNLOAD_LIST)):
            success_count += 1
        time.sleep(1)

    print("\\n" + "=" * 60)
    print(f"全タスク完了: {success_count}/{len(DOWNLOAD_LIST)} ファイルのダウンロードに成功しました！")
    print("=" * 60)

if __name__ == "__main__":
    main()
`;

  return res.json({
    success: true,
    script,
    filename: `download_${mangaTitle.replace(/[\/\?<>\\:\*\|":\s]/g, "_")}.py`
  });
});

// Production & Dev setup for Vite
async function startServer() {
  try {
    if (process.env.NODE_ENV !== "production") {
      const vite = await createViteServer({
        server: { middlewareMode: true },
        appType: "spa",
      });
      app.use(vite.middlewares);
    } else {
      const distPath = path.join(process.cwd(), "dist");
      app.use(express.static(distPath));
      app.get("*", (req, res) => {
        res.sendFile(path.join(distPath, "index.html"));
      });
    }

    app.listen(PORT, "0.0.0.0", () => {
      console.log(`[DL-RAW Server] running on http://0.0.0.0:${PORT}`);
    });
  } catch (error) {
    console.error("[DL-RAW Server] Failed to start server:", error);
  }
}

startServer();
